#include <iostream>
#include <cmath>
#include <string>
#include <sstream>
#include <TH1.h>
#include <TFile.h>
#include "GSource4G4.h"

int main(int argc, char* argv[]){
	istringstream iss(argv[2]);
	int nevnt;
	iss >> nevnt;
	GSource4G4 EuSource(argv[1]);
	EuSource.SetNevent((unsigned long long)nevnt);
	TH1F* hist = new TH1F("intensity","source_intensity",2000,0,2000);
	while(EuSource.IfNext()){
		int n_gamma = EuSource.EmitGamma();
		for(int i=0; i<n_gamma; i++){
			hist->Fill(EuSource.GetEGamma(i));
		}
	}

	cout << "Gamma-ray Intensity" << endl;
	for(int i=0; i<hist->GetNbinsX(); i++){
		double cont = hist->GetBinContent(i);
		if(cont!=0){
			double intensity = 100.0*cont/(double)nevnt;
			double err = intensity*sqrt(1.0/cont + 1.0/(double)nevnt);
			cout << hist->GetBinCenter(i) << " ";
			cout << 100.0*cont/(double)nevnt << " ";
			cout << err << endl;
		}
	}

	TFile *file = new TFile("out.root","RECREATE");
	hist->Write();
	file->Close();
	return 0;
}