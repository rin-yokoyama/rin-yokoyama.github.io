#include<TROOT.h>

void TSlew(string fname = "_file0")
{
  gROOT->ProcessLine(".L GAROOT/src/setgaroot.h");
  gROOT->ProcessLine(".L GAROOT/src/Styles.h");
  gROOT->ProcessLine(".L GAROOT/src/subfunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/ROOTFileReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/TH2MaxGraph.cc");
  gROOT->ProcessLine(".L GAROOT/src/SlewFunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/TResFit.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSlewFit.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSlewShortCuts.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSlew.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSlewMain.cc");
  GSlewMain(fname);    
}
