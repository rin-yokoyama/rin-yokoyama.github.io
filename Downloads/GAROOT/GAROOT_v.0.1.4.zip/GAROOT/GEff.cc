#include<TROOT.h>

void GEff(string fname)
{
  gROOT->ProcessLine(".L GAROOT/src/setgaroot.h");
  gROOT->ProcessLine(".L GAROOT/src/Styles.h");
  gROOT->ProcessLine(".L GAROOT/src/subfunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/ROOTFileReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSource.cc");
  gROOT->ProcessLine(".L GAROOT/src/GCSource.cc");
  gROOT->ProcessLine(".L GAROOT/src/CSVFileStream.cc");
  gROOT->ProcessLine(".L GAROOT/src/GfROOTCSVReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/EffFunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/GEffCalib.cc");
  gROOT->ProcessLine(".L GAROOT/src/GEffMain.cc");
  GEffMain(fname);    
}
