#include<TROOT.h>

void TimeCalib(string fname = "_file0", string psfname = "TimeCalib.ps", string prmfname = "tdc_gains.txt")
{
  gROOT->ProcessLine(".L GAROOT/src/setgaroot.h");
  gROOT->ProcessLine(".L GAROOT/src/subfunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/AOrder.cc");
  gROOT->ProcessLine(".L GAROOT/src/ROOTFileReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/PSPrinter.cc");  
  gROOT->ProcessLine(".L GAROOT/src/TCalibrator.cc");
  gROOT->ProcessLine(".L GAROOT/src/TCalMain.cc");
  TCalMain(fname, psfname, prmfname);
}
