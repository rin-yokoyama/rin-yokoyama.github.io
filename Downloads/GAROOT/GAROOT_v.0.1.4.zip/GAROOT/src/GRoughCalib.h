#include"Gf3ROOT.h"
#include"GSourceList.h"

class GRoughCalib
{
 protected:
  GSource *source[2];
  Int_t Gamma[2];
  Double_t Energy[2];
  Double_t *p0, *p1;
  Int_t npar;
 public:
  GRoughCalib(GSource *s1, Int_t g1, GSource *s2, Int_t g2);
  ~GRoughCalib(void);
  void RoughCalib2P(Gf3ROOT* fGf3ROOT, Int_t f1, Int_t f2); //rough calibration with 2 points
  void WritePrmFile(string fname);
};
