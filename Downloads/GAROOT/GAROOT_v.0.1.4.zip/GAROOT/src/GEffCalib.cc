#include "GEffCalib.h"

GEffCalib::GEffCalib(void){}

GEffCalib::GEffCalib(string conf_f, Int_t histid)
{
  hid = histid;
  ReadConf(conf_f);
}

GEffCalib::~GEffCalib(void){}

void GEffCalib::ReadConf(string conf_f)
{
  ifstream fin(conf_f.c_str(), ios::in);
  if(!fin){ cout << "[GEffCalib-E]: cannot open file:" << conf_f << endl; return; }
  istringstream iss;
  string buf;
  getline(fin, buf);
  iss.str(buf);
  iss >> NFit;
  getline(fin, buf);
  iss.str(buf);
  iss >> NSource;
  Int_t yyyy, mm, dd;
  getline(fin, buf);
  iss.str(buf);
  iss >> yyyy;
  iss >> mm;
  iss >> dd;
  ALSFile = new Int_t[NSource];
  ASFName = new string[NSource];
  Source = new GCSource*[NSource];
  getline(fin, buf);
  for(int i=0; i<NSource; i++){
    getline(fin, buf);
    iss.str(buf);
    iss >> ALSFile[i];
    iss >> ASFName[i];
    Source[i] = new GCSource( ASFName[i] );
    Source[i]->SetDate(yyyy, mm, dd);
  }
  AFitN = new Int_t[NFit];
  ASFile = new Int_t[NFit];
  ASPeak = new Int_t[NFit];
  getline(fin, buf);
  for(int i=0; i<NFit; i++){
    getline(fin, buf);
    istringstream iss2(buf);
    iss2 >> AFitN[i];  
    iss2 >> ASFile[i];
    iss2 >> ASPeak[i];
  }
  fin.close();
  return;
}

TGraphErrors* GEffCalib::MakePlot(string csvfname, Double_t LT)
{
  LiveTime = LT;
  File = new GfROOTCSVReader(csvfname);
  EffCurve = new TGraphErrors(NFit);
  Double_t *AArea = File->GetArray(hid, File->kArea0);
  Double_t *AAError = File->GetArray(hid, File->kAreaE0);
  for(int i=0; i<NFit; i++){
    Double_t cnt = AArea[AFitN[i]];
    Double_t cnt_err = AAError[AFitN[i]];
    Double_t src = Source[ASFile[i]]->GetIntensity(ASPeak[i]);
    Double_t src_err = Source[ASFile[i]]->GetIntError(ASPeak[i]);
    Double_t x = Source[ASFile[i]]->GetEnergy(ASPeak[i]);
    Double_t y = cnt/( (Double_t)LT*src );
    Double_t x_err = Source[ASFile[i]]->GetError(ASPeak[i]);
    Double_t y_err = y*sqrt( cnt_err*cnt_err/(cnt*cnt) + src_err*src_err/(src*src) );
    EffCurve->SetPoint(i,x,y);
    EffCurve->SetPointError(i,x_err, y_err);
  }
  *EffCurve = Graph;
  EffCurve->GetXaxis()->SetTitle("Energy [keV]");
  EffCurve->GetYaxis()->SetTitle("Efficiency");
  return EffCurve;
}

TF1* GEffCalib::MakeFit(EffFuncType func_type)
{
  GEffFunc *func = new GEffFunc();
  Double_t xlow, xup, ylow, yup;
  EffCurve->ComputeRange(xlow, ylow, xup, yup);
  xlow -= 1;
  xup += 1;
  //xlow = 200;
  //xup = 1410;
  func->SetRange(xlow, xup);
  fTF1 = func->CalibFunc(func_type);
  EffCurve->Fit(fTF1,"","",xlow,xup);
  return fTF1;
}

void GEffCalib::Draw(void)
{
  EffCurve->Draw("ap");
}

TGraphErrors* GEffCalib::GetGraph(void)
{
  return EffCurve;
}

TF1* GEffCalib::GetTF1(void)
{
  return fTF1;
}
