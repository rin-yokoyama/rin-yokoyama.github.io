#include "GSlew.h"

//defines shortcuts of GSlew functions
void GSlew::ExecuteShortCut(Int_t event,Int_t px,Int_t py,TObject* sel)
{
  if(event==kWheelDown)
    hn();
  else if(event == kWheelUp)
    hb();
  else if(event == kButton1Shift){ //shift+click
    TCanvas *c = (TCanvas *) gTQSender;
    TPad *pad = (TPad *) c->GetSelectedPad();
    Float_t x = pad->AbsPixeltoX(px);
    Float_t y = pad->AbsPixeltoY(py);
    x = pad->PadtoX(x);
    y = pad->PadtoY(y);
    Expand(x,y);
  }
  else if(event == kKeyPress){
    if((px == 6) && (py == 70)) //ctr+f
      ft();
    if((px == 7) && (py == 71)) //ctr+g
      rmg();
    fTCanvas->Update();
    }
}
