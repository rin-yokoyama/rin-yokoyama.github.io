#include "GSlew.h"
#include "ROOTFileReader.h"
#include <TList.h>
#include <TKey.h>

GSlew *g;
ROOTFileReader* file;
TH2F** hist;

//This will read all 2D histograms from file and create GSlew class.
void GSlewMain(string fname)
{
  if(fname == "_file0"){
    fname = _file0->GetPath();
    fname = fname.substr(0, fname.size() - 2);
  }
  file = new ROOTFileReader(fname);
  Int_t n_obj = file->ReadObj("TH2","TH3");
  cout << "Loading " << n_obj << " TH2" << endl;
  hist = new TH2F[n_obj];
  for(int i=0; i<n_obj; i++)
    hist[i] = (TH2F*)file->GetObj(i);
  g = new GSlew(n_obj, hist);
  return;
}
