#include<iostream>
#include<string>
#include<sstream>
#include<TF1.h>
using namespace std;

#ifndef GAROOT_EFFFUNCs
#define GAROOT_EFFFUNCs

enum EffFuncType {
  kPow = 1, kRadW = 2, kRadWF = 3
};

Double_t EffC( Double_t *x, Double_t *par );

class GEffFunc
{
 protected:
  Int_t f_num;
  string f_name;
  Double_t range[2];
 public:
  GEffFunc(string fname = "GEff", Int_t fnum = 0);
  ~GEffFunc(void);
  void SetRange(Double_t xlow, Double_t xup);
  TF1* CalibFunc(EffFuncType func_type);
};

#endif
