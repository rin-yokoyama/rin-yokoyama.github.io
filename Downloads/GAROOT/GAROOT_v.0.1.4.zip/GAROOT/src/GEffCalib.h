#include "GCSource.h"
#include "GfROOTCSVReader.h"
#include "EffFunctions.h"

class GEffCalib
{
 protected:
  GfROOTCSVReader *File;
  TGraphErrors *EffCurve;
  TF1 *fTF1;
  Int_t hid;
  Int_t NFit;
  Int_t NSource;
  Int_t *ALSFile;
  string *ASFName;
  Int_t *AFitN;
  Int_t *ASFile;
  Int_t *ASPeak;
  GCSource **Source;
  Double_t LiveTime;

  void ReadConf(string conf_f);

 public:
  GEffCalib(void);
  GEffCalib(string conf_f, Int_t histid = 0);
  virtual ~GEffCalib(void);
  TGraphErrors* MakePlot(string csvfname, Double_t LT);
  TF1* MakeFit(EffFuncType func_type);
  void Draw(void);
  TGraphErrors* GetGraph(void);
  TF1 *GetTF1(void);
};
