#include "setgaroot.h"
#include "GfROOTCSVReader.h"
#include "ACorresponder.h"
#include "subfunctions.h"
#include "GSourceList.h"
#include "AOrder.h"
#include "PSPrinter.h"
#include "GCalibFit.h"
#include "CalibFunctions.h"

void ECalMain(string fname, string ofname, string psname)
{
  GfROOTCSVReader* File = new GfROOTCSVReader(fname);
  GSourceList* SourceList = new GSourceList(AppendMacroPath(SRC_LIST));
  GSource* Source;
  Int_t Nhist = File->GetNhist();
  Int_t source_n;
  Double_t gain = 0, offset = 0;

  cout << "Chose a source from below." << endl;
  SourceList->List();
  cout << "input source #: ";
  cin >> source_n;
  cout << "input the gain you assume roughly (in +-20%)." << endl;
  cout << "gain: "; 
  while(gain==0){ cin >> gain; }
  cout << "input limit of the offset (+-input value)." << endl;
  cout << "limit: ";
  while(offset==0){ cin >> offset; }

  Source = new GSource( SourceList->GetSource(source_n) );
  Double_t* RefEnergy = Source->GetEnergy();
  Double_t* RefEnergyE = Source->GetError();
  Int_t NRef = Source->GetNGamma();
  GCalibFit* fGCalibFit = new GCalibFit( ECAL_FUNC);
  PSPrinter* ps = new PSPrinter(psname, Nhist, CANV_W, CANV_H);
  fGCalibFit->Connect("DrawResidual(Int_t)","PSPrinter",ps,"PrintPage(Int_t)");

  for(int i=0; i<Nhist; i++){
    Double_t* Channel = File->GetArray(i, File->kCenter0);
    Double_t* ChannelE = File->GetArray(i, File->kCenterE0);
    Int_t Nfit = File->GetNfit(i);
    AOrder* fAOrder = new AOrder(i);
    fAOrder->Ascend( Channel );
    fAOrder->OrderSame( ChannelE );
    ACorresponder* fACorr = new ACorresponder(Channel, RefEnergy, Nfit, NRef);
    Int_t* ACorr = fACorr->Correspond(offset, gain, gain, offset, 200, 200);
    Double_t* Energy = new Double_t[Nfit];
    Double_t* EnergyE = new Double_t[Nfit];
    for(int j=0; j<Nfit; j++){
      Energy[j] = RefEnergy[ACorr[j]];
      EnergyE[j] = RefEnergyE[ACorr[j]];
    }
    fGCalibFit->CalibFit(Nfit, Channel, Energy, ChannelE, EnergyE);
  }
}
