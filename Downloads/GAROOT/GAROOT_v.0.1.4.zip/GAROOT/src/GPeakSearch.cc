#include "GPeakSearch.h"

GPeakSearch::GPeakSearch(void) : TSpectrum(NP_MAX)
{
  niter = 10;
  sigma = 2;
  threshold = 0.05;
}

GPeakSearch::~GPeakSearch(void){}

Int_t GPeakSearch::PSearch(TH1* HistPtr)
{
  fTH1 = (TH1F*)HistPtr->Clone();
  fTH1BG = (TH1F*)Background(fTH1,niter);
  TH1F* fTH1P = (TH1F*)fTH1->Clone();
  fTH1P->Add(fTH1BG,-1);
  return Search(fTH1P,sigma,"",threshold);
}

void GPeakSearch::SetParam(Double_t thresh, Int_t nit, Double_t sig)
{
  if(thresh < 0)
    thresh = threshold;
  if(nit < 0)
    nit = niter;
  if(sig < 0)
    sig = sigma;
  threshold = thresh;
  niter = nit;
  sigma = sig;
  return;
}

TH1F* GPeakSearch::GetBG(void)
{
  return fTH1BG;
}

void GPeakSearch::GetPMarker(TMarker* mk_ptr[NP_MAX])
{
  Int_t mkn = GetNPeaks();
  Float_t* posXF = GetPositionX();
  Double_t* posX = new Double_t[mkn];
  for(int i=0; i<mkn; i++){
    posX[i] = (Double_t)posXF[i];
  }
  AOrder O(mkn);
  O.Ascend(posX);
  for(int i=0; i<mkn; i++){
    mk_ptr[i]->SetMarkerStyle( PSMarker.GetMarkerStyle() );
    mk_ptr[i]->SetMarkerColor( PSMarker.GetMarkerColor() );
    mk_ptr[i]->SetMarkerSize( PSMarker.GetMarkerSize() );
    mk_ptr[i]->SetX((Double_t)posX[i]);
    mk_ptr[i]->SetY(fTH1->GetBinContent(fTH1->FindBin(mk_ptr[i]->GetX())));
  }
  return;
}
