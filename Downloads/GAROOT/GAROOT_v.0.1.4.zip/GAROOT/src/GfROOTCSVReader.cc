#include"GfROOTCSVReader.h"

GfROOTCSVReader::GfROOTCSVReader(string fname) : CSVFileStream(fname,1,50,1)
{
  ReadtoBuf();
  while(!file.eof()){
    ReadtoBuf();
    nhist = GetInt(0);
  }
  nhist++;
  file.close();
  OpenFile();
  nfit = new int[nhist];
  pos = new int[nhist];
  ReadtoBuf();
  UInt_t sp_hst = file.tellg();
  ReadtoBuf();
  for(int i=0; i<nhist; i++){
    nfit[i] = 1;
    pos[i] = sp_hst;
    ReadtoBuf();
    while(!file.eof() && (i == GetInt(0))){
      nfit[i]++;
      sp_hst = file.tellg();
      ReadtoBuf();
    }
  }
  file.close();
  OpenFile();
}

int GfROOTCSVReader::chk_num(int hist_n)
{
  if( (hist_n < 0) || (hist_n > nhist -1) ){
    cout << "[GfROOTCSVReader-E]: invalid histogram number." << endl;
    return 1;
  }
  else
    return 0;
}

int GfROOTCSVReader::GetNhist(void)
{
  return nhist;
}

int GfROOTCSVReader::GetNfit(int hist_n)
{
  if(chk_num(hist_n)){ return 0; }
  return nfit[hist_n];
}

double* GfROOTCSVReader::GetArray(int hist_n, DataType data_t)
{
  if(chk_num(hist_n)){ return NULL; }
  double* array = new double[nfit[hist_n]];
  file.seekg( pos[hist_n] );
  for(int i=0; i<nfit[hist_n]; i++){
    ReadtoBuf();
    array[i] = GetDouble(data_t);
  }
  return array;
}

