#include "subfunctions.h"
#include "GPeakFitBase.h"
#include <fstream>
#include <sstream>
#include <TROOT.h>
#include "GPeakSearch.h"

class GPeakFit : public GPeakFitBase
{
 protected:
  TF1* fTF1BG; //TF1 for drawing background.
  TMarker* fTMarker[NF_MAX]; //markers for peak search and fit
  TF1* ConstTF1(string f_name, Int_t npk = 1, Double_t xmin = 0, Double_t xmax = 10000); //over rides fitting function with gf3-like function
  Double_t ERes; //energy resolution in sigma (0.001 in default)
  Int_t FixPar[6*NP_MAX+3];
  Double_t FixParVal[6*NP_MAX+3];

 public:
  GPeakSearch* fGPeakSearch;
  GPeakFit(TH1F* hist, Int_t n_fit = NF_MAX);
  virtual ~GPeakFit(void);
  void ClearTF1(Int_t fitn = -1); //reconstructs fTF1[n].
  void FixParams(string pf_name = FIX_PRM); //fixes parameters according to the fixpar file.
  void SetFitting(Int_t npk, Double_t mkpos[2][NM_MAX], Int_t fitn = -1); //sets initial parameters.
  void DrawBG(Int_t fitn); //draws the background part of fitting function.
  void Draw(Option_t* option = ""); //overrides Draw() function of TH1
  void PeakSearch(void); //peak search
  GPeakSearch* GetPeakSearch(void);
  void SetFittingP1(Double_t x, Double_t y); //set parameters from one position
  void MkFit(void); //peak fit for marker positions
  Double_t GetMkX(Int_t mkn); //returns x value of fTMarker
};
