#include"CSVFileStream.h"

class GfROOTCSVReader : public CSVFileStream
{
 public:
  enum DataType{
    kChisq = 2, kBG0 = 3, kBG0E = 4, kBG1 = 5, kBG1E = 6, kBG2 = 7, kBG2E = 8, kArea0 = 9, kAreaE0 = 10, kCenter0 = 11, kCenterE0 = 12, kSigma0 = 13, kSigmaE0 = 14, 
  };
 protected:
  int nhist; //number of hists
  int* nfit; //number of fits in each hist
  int* pos; //position of the first line of each hist
  int chk_num(int hist_n);

 public:
  GfROOTCSVReader(string fname);
  virtual ~GfROOTCSVReader(void);
  int GetNhist(void);
  int GetNfit(int hist_n);
  double* GetArray(int hist_n, DataType data_t);
};
