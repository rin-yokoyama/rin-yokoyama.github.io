#include "GCSource.h"

GCSource::GCSource(string sc_fname) : GSource()
{
  RefDate = new TDatime();
  CurDate = new TDatime();
  ReadCSourceFile(sc_fname);
  ReadSourceFile(sourcefile);
}

GCSource::~GCSource(void){}

void GCSource::ReadCSourceFile(string fname)
{
  ifstream fin(AppendMacroPath(fname).c_str(), ios::in);
  if(!fin){ cout << "[GCSource-E]: cannot open file: " << fname << endl; return; }
  string buf;
  istringstream iss;
  Int_t yy, mm, dd;
  getline(fin, SName);
  getline(fin, buf);
  iss.str(buf);
  iss >> yy;
  iss >> mm;
  iss >> dd;
  getline(fin, buf);
  iss.str(buf);
  iss >> RefInt;
  RefInt *= 1000;
  getline(fin, buf);
  iss.str(buf);
  iss >> RefIntError;
  getline(fin, buf);
  iss.str(buf);
  iss >> sourcefile;
  RefDate->Set(yy, mm, dd, 0, 0 ,0);
  return;
}

void GCSource::SetDate(Int_t yyyy, Int_t mm, Int_t dd, Int_t hour, Int_t min, Int_t sec)
{
  CurDate->Set(yyyy, mm, dd, hour, min, sec);
  UInt_t cd = CurDate->Convert();
  cd -= RefDate->Convert();
  CurInt = RefInt*pow(0.5, (Double_t)cd/(Double_t)HalfLife);
  return;
}

Double_t GCSource::GetIntensity(Int_t i_gamma)
{
  return RelInt[i_gamma]*CurInt;
}

Double_t GCSource::GetIntError(Int_t i_gamma)
{
  Double_t CurIntE = CurInt*RefIntError/RefInt;
    return RelInt[i_gamma]*CurInt*sqrt(CurIntE*CurIntE/(CurInt*CurInt) + RelIntE[i_gamma]*RelIntE[i_gamma]/(RelInt[i_gamma]*RelInt[i_gamma]));
}
