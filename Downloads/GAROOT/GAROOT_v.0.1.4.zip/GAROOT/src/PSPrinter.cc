#include"PSPrinter.h"

PSPrinter::PSPrinter(string fname, Int_t n_page, Int_t width, Int_t height) : TCanvas("PSPrinter",fname.c_str(), width, height)
{
  filename = fname;
  npage = n_page;
}

PSPrinter::~PSPrinter(void){}

void PSPrinter::PrintPage(Int_t pn)
{
  string file = filename;
  if(!pn){ file = file.append("("); }
  if(pn == npage - 1){ file = file.append(")"); }
  Print(file.c_str());
}
