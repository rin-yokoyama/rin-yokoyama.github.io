#include<iostream>
#include<string>
using namespace std;

string AppendMacroPath(string fname);
