#include"GRoughCalib.h"
#include"CalibFunctions.h"

GRoughCalib::GRoughCalib(GSource *s1, Int_t g1, GSource *s2, Int_t g2)
{
  source[0] = s1;
  source[1] = s2;
  Gamma[0] = g1;
  Gamma[1] = g2;
  for(int i=0; i<2; i++){
    Double_t* e = source[i]->GetEnergy();
    Energy[i] = e[Gamma[i]];
  }
}

GRoughCalib::~GRoughCalib(void)
{
  delete [] p0;
  delete [] p1;
}

void GRoughCalib::RoughCalib2P(Gf3ROOT* fGf3ROOT, Int_t f1, Int_t f2)
{
  npar = fGf3ROOT->GetNHist();
  p0 = new Double_t[npar];
  p1 = new Double_t[npar];
  for(int i=0; i<npar; i++){
    Double_t Channel[2];
    Channel[0] = fGf3ROOT->fGPeakFit[i]->GetTF1(f1)->GetParameter(4);
    Channel[1] = fGf3ROOT->fGPeakFit[i]->GetTF1(f2)->GetParameter(4);
    p1[i] = (Energy[1] - Energy[0])/(Channel[1] - Channel[0]);
    p0[i] = Energy[0] - p1[i]*Channel[0];
  }
  return;
}

void GRoughCalib::WritePrmFile(string fname)
{
  ofstream fout(fname.c_str(), ios::out);
  fout << kLine << endl;
  for(int i=0; i<npar; i++)
    fout << p0[i] << " " << p1[i] << endl;
  fout.close();
}
