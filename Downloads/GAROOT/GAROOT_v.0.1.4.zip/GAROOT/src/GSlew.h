#include <new>
#include <TStyle.h>
#include <TCanvas.h>
#include <TFile.h>
#include <RQ_OBJECT.h>
#include "GSlewFit.h"
#include "TResFit.h"

class GSlew
{
  RQ_OBJECT("GSlew")
 protected:
  Int_t n_hist; //number of histograms
  Int_t hid; //current histogram number
  Int_t mode;
  Double_t xmin_com, ymin_com, xmax_com, ymax_com;

  Int_t CheckHN(Int_t hn); //check if input histn is valid
  void ConnectShortCut();
  void Expand(Double_t x, Double_t y);

 public:
  GSlewFit **fGSlewFit;
  TCanvas *fTCanvas;

  GSlew(Int_t nhist, TH2F** fTH2F);
  virtual ~GSlew(void);
  void ExecuteShortCut(Int_t event,Int_t px,Int_t py,TObject* sel);
  void mg(Int_t rebinx = 1, Int_t rebiny = 1); //creates graphs of maximum points
  void rmg(Int_t rebinx = 0, Int_t rebiny = 0, Double_t ylow = 0, Double_t yup = 0); //recreates graphs
  void ht(Int_t id = -1); //draws histogram[id]
  void hn(); //next histogram
  void hb(); //previous histogram
  void zoom(Double_t xlow, Double_t xup, Double_t ylow, Double_t yup);
  void ft(); //fit all graphs
  void tr(Double_t Offset=0, Double_t thresh=0, Int_t rebinx=1, Double_t gain=1, Double_t max=500); //creates resolution graphs
  void FixParam(Int_t ipar, string parfile);
  void WriteCSV(string fname);
  void WriteROOTFile(string fname, Option_t* opt);
  void PrintAll(string fname);
};
