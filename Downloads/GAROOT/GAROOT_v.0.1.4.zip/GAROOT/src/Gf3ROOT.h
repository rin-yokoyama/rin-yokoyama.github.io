#include <fstream>
#include "subfunctions.h"
#include "GPeakFit.h"
#include "MkMouse.h"
#include "GPeakSearch.h"
#include "GSourceList.h"
#include "GRoughCalib.h"
#include "CSVFileStream.h"
#include "ROOTFileReader.h"
#include <TCanvas.h>
#include <TMarker.h>
#include <TStyle.h>
#include <TPad.h>
#include <RQ_OBJECT>

class Gf3ROOT
{
  RQ_OBJECT("Gf3ROOT")
 protected:
  Int_t n_hist; //number of histograms
  Int_t hid; //current histogram number
  Int_t mode; //current mode. (0:normal, 1:qf mode)
  Double_t xmin_com, xmax_com; //common range
  Int_t CheckHN(Int_t hn); //check if input histn is valid
  Option_t* op; //option for fitting
  Option_t* gop; //goption for fitting
  void Fit(Int_t event,Int_t px,Int_t py,TObject* sel); //Fit
  void QFit(Int_t event,Int_t px,Int_t py,TObject* sel); //QuickFit
  void Expand(Double_t x);
  void ConnectShortCut();

 public:
  MkMouse *fMkMouse;
  TCanvas *fTCanvas;
  GPeakFit* fGPeakFit[NH_MAX];

  Gf3ROOT(Int_t Nhist, TH1F* fTH1F[NH_MAX]);
  ~Gf3ROOT(void);
  void ExecuteShortCut(Int_t event,Int_t px,Int_t py,TObject* sel);
  Int_t GetNHist();
  void fn(Int_t fitn);
  void nf(Option_t* option = "", Option_t* goption = ""); //new fit
  void qf(); //sets quick fit mode #2
  void ps(Double_t threshold  = -1, Int_t niter = -1, Double_t sigma = -1); //peak search
  void mf(); //fit markers
  void esc(); //escapes
  void ht(Int_t id = -1); //draws histogram
  void hn(); //next histogram
  void hb(); //previous histogram
  void fn(); //next TF1
  void fb(); //previous TF1
  void zoom(Double_t low, Double_t up); //zoom all histograms
  void unzoom(); //unzoom all histograms
  void WriteCSV(string ofname, Int_t fidlow = 0, Int_t fidup = NF_MAX); //writes fitting parameters into a csv file.
  void RoughCalib(string ofname); //2 peak calibration
  void PrintAll(string ps_file); //prints all histograms as a ps file
  void ListMkPos(void); //lists x, y value of fTMarker[0]
  void SaveFits(Int_t fidlow = 0, Int_t fidup = NF_MAX, string ffname = "GfROOTfits.root"); //saves TF1s in the fGPeakFit[hid].
  void FileFit(string ffname = "GfROOTfits.root"); //fits all histograms by TF1s in the file
};
