#include <TAxis.h>
#include "TH2MaxGraph.h"
#include "subfunctions.h"
#include "SlewFunctions.h"
#include "TResFit.h"

class GSlewFit : public TResFit, public TH2MaxGraph
{
 protected:
  TF1 *fTF1;
  Int_t hnum;
  Int_t npar;
  string xtitle, ytitle;
  string d_opt_hist;
  string d_opt_graph;
  SlewFuncType f_type;
  Double_t* init_param;
 public:
  GSlewFit(TH2* fTH2, string conf_f, Int_t h_num = 0);
  ~GSlewFit(void);
  void ReadConf(string f_name);
  void SlewFit();
  void Fit();
  void Draw(void);
  TF1* GetTF1(void);
  Int_t GetNpar(void);
  TGraph* PlotZero(Double_t Offset, Double_t thresh, Int_t rebinx, Double_t gain, Double_t max);
};
