#include <TAttLine.h>
#include <TAttFill.h>
#include <TAttMarker.h>

//defines Fit and Histogram styles.
//TAttLine(color, style, width), TAttFill(color, style)
TAttLine GFitLine(kRed, 1, 2); //the style of fitting functions
TAttLine GBGLine(kBlack, 1, 1); //the style of background part of fitting functions

//styles of histograms
TAttLine GHistLine(kBlue+3, 1, 1);
TAttFill GHistFill(kBlue+3, 0);

TAttMarker PSMarker(kRed, 23, 1); // the style of markers for peak search.
TAttMarker Graph(kRed, 8, 0.8); //the style of TGraphs
