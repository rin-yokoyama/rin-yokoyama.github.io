#include "ACorresponder.h"

ACorresponder::ACorresponder(Double_t* ArrayA, Double_t* ArrayB, Int_t nArrayA, Int_t nArrayB)
{
  nA = nArrayA;
  nB = nArrayB;
  ACorrReturn = new Int_t[nA];
  Array = new Double_t[nA+nB];
  int n = nA + nB;
  for(int i=0; i<nA; i++){
    Array[i] = ArrayA[i];
  }
  for(int i=nA; i<n; i++){
    Array[i] = ArrayB[i-nA];
  }
  fTF2 = new TF2("ACorrfTF2",ACorresponder::MinDev, -10, 10, 0, 10, n+2);
  fTF2->FixParameter(0, nA);
  fTF2->FixParameter(1, nB);
  for(int i=0; i<n; i++)
    fTF2->FixParameter(i+2, Array[i]);
}

ACorresponder::~ACorresponder(void){}

Double_t ACorresponder::MinDev(Double_t *x, Double_t* par)
{
  Double_t xx = x[0];
  Double_t xy = x[1];
  Double_t f = 0;
  Int_t nArrayA = (Int_t)par[0];
  Int_t nArrayB = (Int_t)par[1];
  Int_t nArray = nArrayA + nArrayB;
  for(int i=2; i<nArrayA+2; i++){
    Double_t calA = xx + xy*par[i];
    Double_t min = (calA - par[nArrayA+2])*(calA - par[nArrayA+2])/calA*calA;
    ACorrReturn[i-2] = 0;
    //cout << i-2 << ": ";
    for(int j=nArrayA+3; j<nArray+2; j++){
      Double_t ch = (calA - par[j])*(calA - par[j])/calA*calA;
      if( min > ch ){
	min = ch;
	ACorrReturn[i-2] = j - nArrayA - 2;
	//cout << calA << " " << par[j]  << " " << j-nArrayA-2 << ": ";
      }
    }
    //cout << endl;
    f += min;
  }
  return f;
}

Int_t* ACorresponder::Correspond(Double_t& x, Double_t& y, Double_t gain, Double_t ROffSet, Int_t Npx, Int_t Npy)
{
  fTF2->SetNpx(Npx);
  fTF2->SetNpy(Npy);
  fTF2->SetRange(-ROffSet, gain - gain*0.2, ROffSet, gain + gain*0.2);
  fTF2->GetMinimumXY(x,y);
  return ACorrReturn;
}
