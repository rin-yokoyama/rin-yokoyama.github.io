#include<new>
#include"GPeakFit.h"

class GAutoFit
{
 protected:
  GPeakFit *fGPeakFit;
  Int_t nfit; //number of fTF1s
  Int_t *npeak; //array of the numbers of peaks
  string *fixprmfile; //array of the fixprmfile names
  Double_t *xmin; //array of the  mimima of fit ranges
  Double_t *xmax; //array of the maxima of fit ranges
  Double_t **peak; //array of the peak centers
 public:
  GAutoFit(string confname);
  ~GAutoFit(void);
  void ReadConf(string confname); //reads parameters from conf file
  void AutoFit(TH1* Hist);
};
