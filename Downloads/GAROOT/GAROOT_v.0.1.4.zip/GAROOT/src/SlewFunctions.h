#include<iostream>
#include<string>
#include<sstream>
#include<TF1.h>
using namespace std;

#ifndef GAROOT_SLEWFUNCs
#define GAROOT_SLEWFUNCs

enum SlewFuncType {
  kSqrt = 1, kArbD = 2, kStep = 3
};

class GSlewFunc
{
 protected:
  Int_t f_num;
  string f_name;
  Double_t range[2];
 public:
  GSlewFunc(string fname = "GSlew", Int_t fnum = 0);
  ~GSlewFunc(void);
  void SetRange(Double_t xlow, Double_t xup);
  TF1* CalibFunc(SlewFuncType func_type);
};

#endif
