#include "EffFunctions.h"

Double_t EffC( Double_t *x, Double_t *par ){
  Float_t xx = x[0];
  Double_t f;
  f = exp( pow( pow( par[0]+par[1]*log(x/par[2]), -par[6] ) + pow( par[3]+par[4]*log(x/par[5]), -par[6]), -1.0/par[6] ) );
  return f;
}

GEffFunc::GEffFunc(string fname, Int_t fnum)
{
  f_num = fnum;
  f_name = fname;
  range[0] = 0;
  range[1] = 10000;
}

GEffFunc::~GEffFunc(void){}

void GEffFunc::SetRange(Double_t xlow, Double_t xup)
{
  range[0] = xlow;
  range[1] = xup;
}

TF1* GEffFunc::CalibFunc(EffFuncType func_type)
{
  TF1 *fTF1;
  ostringstream oss;
  oss.str("");
  oss << f_name << f_num;
  if(func_type == kPow){
    fTF1 = new TF1(oss.str().c_str(), "[0]*pow(x,[1])", range[0], range[1]);
    fTF1->SetParameters(0.5,-0.8);
  }
  if(func_type == kRadW){
    //fTF1 = new TF1(oss.str().c_str(), "exp( TMath::Power( TMath::Power( [0]+[1]*log(x/[2]),-[6]) + TMath::Power( [3]+[4]*log(x/[5]), -[6]), -1.0/[6] ) )",range[0],range[1]);
    fTF1 = new TF1(oss.str().c_str(), "exp( 1.0/( 1.0/( [0]+[1]*log(x/[2]) ) + 1.0/( [3]+[4]*log(x/[5])) ) )",range[0],range[1]);
    //fTF1 = new TF1(oss.str().c_str(), EffC, range[0], range[1], 7);
    fTF1->SetParameters(5, 3, 100, -6, -0.7, 1000, 1);
    //fTF1->SetParLimits(0,0.999,1.001);
    fTF1->FixParameter(6,1);
    fTF1->SetParLimits(0,1,500);
    fTF1->SetParLimits(1,1,500);
    fTF1->SetParLimits(3,-10,-0.1);
    fTF1->SetParLimits(4,-10,-0.1);
    fTF1->FixParameter(2,100);
    fTF1->FixParameter(5,1000);
  }
  if(func_type == kRadWF){
    fTF1 = new TF1(oss.str().c_str(), "exp( pow( pow( [0]+[1]*log(x/[7])+[2]*pow(log(x/[7]),2), -[6] ) + pow( [3]+[4]*log(x/[8])+[5]*pow(log(x/[8]), 2), -[6]), -1.0/[6] ) )",range[0],range[1]);
    fTF1->SetParameters(7, 1, 0, 5, -0.9, 0, 20, 100, 1000);
    fTF1->FixParameter(7,100);
    fTF1->FixParameter(8,1000);
  }
  return (TF1*)fTF1->Clone();
}
