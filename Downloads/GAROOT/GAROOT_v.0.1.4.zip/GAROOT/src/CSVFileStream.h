#include<iostream>
#include<string>
#include<fstream>
#include<sstream>
#include<new>
using namespace std;

class CSVFileStream
{
 protected:
  int ro;
  int nraw;
  int ncol;
  string **buffer;
  fstream file;
  string filename;

  int chk_ro();
  int chk_num(int raw = 0, int col = 0);

 public:
  CSVFileStream(string fname, int read_only, int buf_col, int buf_raw = 1);
  virtual ~CSVFileStream(void);
  void OpenFile();
  void CloseFile();
  void SetLine(string *line, int raw = 0);
  void SetString(string content, int col, int raw = 0);
  void SetInt(int content, int col, int raw = 0);
  void SetDouble(double content, int col, int raw = 0);
  void WriteLine(int raw = 0);
  void WriteBuf();
  void ClearBuf();
  void ReadtoBuf();
  string GetString(int col, int raw = 0);
  int GetInt(int col, int raw = 0);
  double GetDouble(int col, int raw = 0);
  fstream* GetFileStream(void);
};
