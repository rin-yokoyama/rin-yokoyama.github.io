#include"GCalibManager.h"
#include<TFile.h>

void GCalibMain(string rfname, string pfname, Int_t nbin = 4000, Int_t hid0 = 0, Int_t hidn = -1)
{
  try{
    if(rfname == ""){
      rfname = _file0->GetPath();
      rfname = rfname.substr(0, rfname.size() - 2);
    }
    file = new ROOTFileReader(rfname);    
    Int_t n_obj = file->ReadObj("TH1","TH2");
    if(hidn>0)
      n_obj = hidn;
    TH1F** hist = new TH1F[n_obj];
    for(int i=hid0; i<n_obj; i++)
      hist[i] = (TH1F*)file->GetObj(i);
    GCalibManager *g = new GCalibManager(hist, pfname, n_obj);
    rfname = rfname.substr(0, rfname.find_last_of('.') );
    rfname.append("_calib.root");
    TFile *fout = new TFile(rfname.c_str(), "RECREATE");
    for(int i=0; i<n_obj; i++){
      string hname = hist[i]->GetName();
      hname = hname.append("_calib");
      g->GCalib(i, nbin)->Write(hname.c_str());
    }
    fout->Close();
  }
  catch(bad_alloc){
    cout << "[GCalibMain-E]: Exception bad_alloc." << endl;
    return;
  }
  return;
}
