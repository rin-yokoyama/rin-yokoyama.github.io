#include <TH2.h>
#include <TGraph.h>
#include "Styles.h"

class TResFit
{
 protected:
  TH2F* fTH2F;
  TGraph* fTResGraph;
 public:
  TResFit(void);
  TResFit(TH2* fTH2);
  virtual ~TResFit(void);
  void SetGraph(TGraph &ptr);
  TGraph* PlotRes(Int_t Nsigma, Int_t rebinx, Double_t center, Double_t max);
  TGraph* PlotZero(Double_t Offset, Double_t thresh, Int_t rebinx, Double_t gain, Double_t max);
};
