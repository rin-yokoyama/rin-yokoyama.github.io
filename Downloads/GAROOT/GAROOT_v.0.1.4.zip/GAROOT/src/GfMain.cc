#include "Gf3ROOT.h"
#include "ROOTFileReader.h"
#include <TList.h>
#include <TKey.h>

Gf3ROOT *g;
ROOTFileReader* file;
TH1F** hist;

//This will read all histograms from file and create Gf3ROOT class.
void GfMain(string hist_prefix, Int_t id_low, Int_t id_up, string fname)
{
  if(fname == "_file0"){
    fname = _file0->GetPath();
    fname = fname.substr(0, fname.size() - 2);
  }
  file = new ROOTFileReader(fname);
  
  Int_t n_obj = 0;
  TH1F** hist;

  if(hist_prefix==""){
    n_obj = file->ReadObj("TH1","TH2");
    hist = new TH1F[n_obj];
    for(int i=0; i<n_obj; i++)
      hist[i] = (TH1F*)file->GetObj(i);
  }
  else{
    if(!id_low && !id_up){
      Int_t n = file->ReadObj("TH1","TH2");
      TH1F *tmp;
      Int_t nchar = hist_prefix.size();
      for(int i=0; i<n; i++){
	tmp = (TH1F*)file->GetObj(i);
	string hname = tmp->GetName();
	if(hname.substr(0,nchar) == hist_prefix)
	  n_obj++;
      }
      hist = new TH1F[n_obj];
      int j=0;
      for(int i=0; i<n; i++){
 	tmp = (TH1F*)file->GetObj(i);
	string hname = tmp->GetName();
	if(hname.substr(0,nchar) == hist_prefix){
	  hist[j] = tmp;
	  j++;
        }
      }
    }
    else{
      Int_t n_obj = id_up - id_low +1;
      hist = new TH1F[n_obj];
      TFile *ifile = new TFile(fname.c_str());
      for(int i=0; i<n_obj; i++){
	ostringstream oss;
	oss << hist_prefix << id_low + i;
	hist[i] = (TH1F*)ifile->Get(oss.str().c_str());
      }
    }
  }

  g = new Gf3ROOT(n_obj, hist);
  return;
}
