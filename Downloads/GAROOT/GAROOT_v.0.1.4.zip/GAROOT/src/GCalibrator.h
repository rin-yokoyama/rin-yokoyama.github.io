#include"CalibFunctions.h"
#include<TRandom.h>
#include<TH1.h>

class GCalibrator
{
 protected:
  enum CalFuncType f_type;
  GCalibFunc *fGCalibFunc;
  Int_t npar;
  Double_t* par;
  TF1* fTF1;
 public:
  GCalibrator(CalFuncType func_type, Double_t *parameter, Int_t num = 0);
  virtual ~GCalibrator(void);
  TH1F* GCalib(TH1F* fTH1, Int_t nbin = 4000);
  Int_t GetNpar(void);
};
