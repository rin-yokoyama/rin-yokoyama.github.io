#include<iostream>
#include<fstream>
#include<sstream>
#include<TH1.h>
#include<TGraph.h>
#include<TSpectrum.h>
#include<RQ_OBJECT.h>
#include"subfunctions.h"
#include"Styles.h"
#include"AOrder.h"
using namespace std;

class TCalibrator
{
  RQ_OBJECT("TCalibrator")
 protected:
  Int_t nhist; //number of histograms
  Double_t t_interval; //time interval of the pulse
  Double_t sigma; //sigma for peak search
  string option; //option for peak search
  Double_t threshold; //threshold for peak search
  Int_t* npk; //number of peaks for each histogram
  Double_t** pkpos; //buffer for the peak positions
  Double_t* mean;
  TH1F** fTH1;

  void ReadConf(string fname); //reads configuration file

 public:
  TCalibrator(TH1** hist, Int_t hnum, Double_t interval, string conf_file = TCAL_CONF);
  virtual ~TCalbrator(void);
  void SearchPeak(Int_t draw = 0); //peak search
  void Calibrate(Int_t draw = 0); //calibrates and draws plots of gains
  void WriteGains(string fname);
};
