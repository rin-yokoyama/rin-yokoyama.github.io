#include "GEffCalib.h"

Int_t nhist; //number of histograms
string csvfname; //name of the input GfROOTCSV file
string *title; //title of the graph
string parfname; //name of the output parameter file
EffFuncType func_type; //type of the efficiency fitting function
string psfname; //name of the output ps file
string *confname; //array of configuration files for GEffCalib
Double_t *LT; //live times
TGraphErrors *gr;

void GEffMain(string fname)
{
  //reads configuration file
  ifstream fin(fname.c_str(), ios::in);
  if(!fin){ cout << "[GEffMain-E]: cannot open file: " << fname << endl; return; }
  istringstream iss;
  string buf;
  getline(fin, buf);
  iss.str(buf);
  iss >> nhist; 
  getline(fin, buf);
  iss.str(buf);
  iss >> csvfname;
  getline(fin, buf);
  iss.str(buf);
  iss >> psfname;
  getline(fin, buf);
  iss.str(buf);
  iss >> parfname;
  getline(fin, buf);
  iss.str(buf);
  iss >> func_type;
  confname = new string[nhist];
  Title = new string[nhist];
  LT = new Double_t[nhist];
  getline(fin,buf);
  for(int i=0; i<nhist; i++){
    getline(fin, buf);
    istringstream iss2(buf);
    iss2 >> LT[i];
    iss2 >> confname[i];
    iss2 >> Title[i];
  }
  
  gStyle->SetOptFit();
  TCanvas *canv = new TCanvas("Eff_canv","Eff_canv", 10, 10, CANV_W, CANV_H);
  canv->SetLogx();
  canv->SetLogy();
  GEffCalib **fGEffCalib;
  fGEffCalib = new GEffCalib*[nhist];
  canv->Print(psfname.append("[").c_str());
  for(int i=0; i<nhist; i++){
    fGEffCalib[i] = new GEffCalib(confname[i], i);
    fGEffCalib[i]->MakePlot(csvfname, LT[i])->SetTitle(Title[i].c_str());
    if(i==7)
      gr = fGEffCalib[i]->GetGraph();
    fGEffCalib[i]->Draw();
    fGEffCalib[i]->MakeFit(func_type); 
    if(i<nhist-1)
      canv->Print(psfname.c_str());
    else
      canv->Print(psfname.append(")").c_str());
  }

  ofstream fout(parfname.c_str(), ios::out);
  fout << "title, chisq, ";
  Int_t npar = fGEffCalib[0]->GetTF1()->GetNpar();
  for(int i=0; i<npar; i++){
    fout << "p" << i << ", error, ";
  }
  fout << endl;
  for(int i=0; i<nhist; i++){
    fout << fGEffCalib[i]->GetGraph()->GetTitle();
    fout << ", " << fGEffCalib[i]->GetTF1()->GetChisquare() << ", ";
    for(int j=0; j<npar; j++){
      fout << fGEffCalib[i]->GetTF1()->GetParameter(j) << ", ";
      fout << fGEffCalib[i]->GetTF1()->GetParError(j) << ", ";
    }
    fout << endl;
  }
  fout.close();

  TGraphErrors** graph;
  graph = new TGraphErrors*[nhist];
  TFile *ROOTfile = new TFile("out.root","RECREATE");
  for(int i=0; i<nhist; i++){
    ostringstream oss;
    oss << "graph" << i;
    graph[i] = fGEffCalib[i]->GetGraph();
    graph[i]->Write(oss.str().c_str());
  }
  ROOTfile->Close();

  return;
}
