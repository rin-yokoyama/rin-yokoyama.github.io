#include"GCalibrator.h"

GCalibrator::GCalibrator(CalFuncType func_type, Double_t *parameter, Int_t num)
{
  f_type = func_type;
  fGCalibFunc = new GCalibFunc("GCalib",num);
  fTF1 = fGCalibFunc->CalibFunc(f_type);
  npar = fTF1->GetNpar();
  par = new Double_t[npar];
  for(int i=0; i<npar; i++){
    par[i] = parameter[i];
  }
  fTF1->SetParameters(par);
}

GCalibrator::~GCalibrator(void)
{
}

TH1F* GCalibrator::GCalib(TH1F* fTH1, Int_t nbin)
{
  TH1F* fTH1F;
  Double_t xmin = fTH1->GetXaxis()->GetXmin();
  Double_t xmax = fTH1->GetXaxis()->GetXmax();
  fGCalibFunc->SetRange(xmin, xmax);
  string ftitle = fTH1->GetTitle();
  ftitle.append("_Calib");
  string fname = fTH1->GetName();
  fname.append("_Calib");
  fTH1F = new TH1F(fname.c_str(), ftitle.c_str(), nbin, fTF1->Eval(xmin), fTF1->Eval(xmax));
  TRandom *r = new TRandom();
  for(int i=0; i<fTH1->GetNbinsX(); i++){
    for(int j=0; j<fTH1->GetBinContent(i); j++){
      Double_t val = fTH1->GetBinCenter(i) + r->Uniform(-0.5,0.5);
      val = fTF1->Eval(val);
      fTH1F->Fill(val);
    }
  }
  return (TH1F*)fTH1F->Clone();
}

Int_t GCalibrator::GetNpar(void)
{
  return npar;
}
