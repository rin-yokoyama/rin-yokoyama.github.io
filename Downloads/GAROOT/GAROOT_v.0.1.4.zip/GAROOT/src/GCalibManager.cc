#include"GCalibManager.h"

GCalibManager::GCalibManager(TH1F** Hist, string fname, Int_t nhist)
{
  try{
    fTH1F = new TH1F[nhist];
    for(int i=0; i<nhist; i++)
      fTH1F[i] = Hist[i];
    n_hist = nhist;
    ReadFile(fname);
  }
  catch(bad_alloc){
    cout << "[GCalibManager-E]: bad_alloc." << endl;
    throw;
    }
}

GCalibManager::~GCalibManager(void){}

void GCalibManager::ReadFile(string fname)
{
  try{
    ifstream fin(fname.c_str(), ios::in);
    if(!fin){
      cout << "[GCalibManager-E]: cannot open parameter file: " << fname << endl;
      throw 1; 
    }
    enum CalFuncType f_type;
    fin >> f_type;
    GCalibFunc *fGCalibFunc = new GCalibFunc();
    fGCalibrator = new GCalibrator[n_hist];
    TF1* Func = fGCalibFunc->CalibFunc(f_type);
    n_par = Func->GetNpar();
    Double_t **par;
    par = new Double_t*[n_hist];
    for(int i=0; i<n_hist; i++){
      par[i] = new Double_t[n_par];
      for(int j=0; j<n_par; j++)
	fin >> par[i][j];
      fGCalibrator[i] = new GCalibrator(f_type, par[i], i);
      }
  }
  catch(bad_alloc){
    cout << "[GCalibManager-E]: Exception bad_alloc." << endl;
    throw;
  }
}

TH1F* GCalibManager::GCalib(Int_t hn, Int_t nbin)
{
  return fGCalibrator[hn]->GCalib(fTH1F[hn],nbin);
}
