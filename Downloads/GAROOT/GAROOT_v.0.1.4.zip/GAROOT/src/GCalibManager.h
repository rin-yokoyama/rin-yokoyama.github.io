#include<iostream>
#include<fstream>
#include<new>
#include"GCalibrator.h"
using namespace std;
class GCalibManager
{
 protected:
  Int_t n_hist;
  Int_t n_par;
  TH1F** fTH1F;
  GCalibrator **fGCalibrator;
  void ReadFile(string fname);
 public:
  GCalibManager(TH1F** Hist, string fname, Int_t nhist);
  ~GCalibManager(void);
  TH1F* GCalib(Int_t hn, Int_t nbin = 4000);
};
