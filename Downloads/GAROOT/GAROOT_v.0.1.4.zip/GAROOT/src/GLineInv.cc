#include"GLineInv.h"

GLineInv::GLineInv(Double_t p0, Double_t p1) : TF1(name.c_str(), "pol1(0)", xmin, xmax)
{
  SetParameter(0, - p0/p1);
  SetParameter(1, 1/p1);
}
