#include<TH2.h>
#include<TF1.h>
#include<TGraph.h>
#include"Styles.h"

class TH2MaxGraph
{
 protected:
  TH2F *fTH2F;
  TGraph *fTGraph;
  Double_t ymax, ymin;
  Int_t rbinx, rbiny;
  Int_t ifgconst;
 public:
  TH2MaxGraph(TH2 *fTH2);
  virtual ~TH2MaxGraph(void);
  TGraph* MaxGraph(Int_t rebinx = 0, Int_t rebiny = 0, Double_t ylow = 0, Double_t yup = 0);
  TH2F* GetTH2(void);
  TGraph* GetTGraph(void);
};
