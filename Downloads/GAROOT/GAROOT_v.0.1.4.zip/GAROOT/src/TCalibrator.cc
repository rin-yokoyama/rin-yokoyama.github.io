#include"TCalibrator.h"

TCalibrator::TCalibrator(TH1** hist, Int_t hnum, Double_t interval, string conf_file)
{
  nhist = hnum;
  fTH1 = new TH1F[nhist];
  pkpos = new Double_t*[nhist];
  npk = new Int_t[nhist];
  mean = new Double_t[nhist];
  for(int i=0; i<nhist; i++){
    fTH1[i] = (TH1F*)hist[i];
    fTH1[i]->SetXTitle("TDC Channel");
    fTH1[i]->SetYTitle("count");
  }
  t_interval = interval;
  ReadConf(conf_file);
}

TCalibrator::~TCalibrator(void){}

void TCalibrator::ReadConf(string fname)
{
  ifstream fin(AppendMacroPath(fname).c_str(), ios::in);
  if(!fin){
    cout << "[TCalibrator-E]: cannot open conf file: " << fname << endl;
    sigma = 1;
    threshold = 0.1;
    return;
  }
  istringstream oss;
  string str;
  getline( fin, str );
  oss.str(str);
  oss >> sigma;
  getline( fin, str );
  oss.str(str);
  oss >> threshold;
  getline( fin, str );
  oss.str(str);
  oss >> option;
  fin.close();
}

void TCalibrator::SearchPeak(Int_t draw)
{
  TSpectrum *sp = new TSpectrum();
  for(int i=0; i<nhist; i++){
    sp->Search(fTH1[i], sigma, option.c_str(), threshold);
    npk[i] = sp->GetNPeaks();
    pkpos[i] = new Double_t[npk[i]];
    Float_t* posx = new Float_t[npk[i]];
    posx = sp->GetPositionX();
    for(int j=0; j<npk[i]; j++)
      pkpos[i][j] = posx[j];
    AOrder *Order = new AOrder(npk[i]);
    Order->Ascend(pkpos[i]);
    if(draw){
      fTH1[i]->Draw("");
      Emit("SearchPeak(Int_t)", i);
    }
  }
}

void TCalibrator::Calibrate(Int_t draw)
{
  for(int i=0; i<nhist; i++){
    TGraph* gr = new TGraph(npk[i]-1);
    *gr = Graph;
    string title = fTH1[i]->GetTitle();
    title = title.append("_gain");
    gr->SetTitle(title.c_str());
    gr->GetXaxis()->SetTitle("TDC Channel");
    gr->GetYaxis()->SetTitle("TDC Gain");
    for(int j=0; j<npk[i]-1; j++){
      Double_t gain = t_interval/(pkpos[i][j+1] - pkpos[i][j]);
      Double_t xavg = (pkpos[i][j+1] + pkpos[i][j])/2.0;
      gr->SetPoint(j,xavg,gain);
    }
    mean[i] = gr->GetMean(2);
    if(draw){
      gr->Draw("AP");
      Emit("Calibrate(Int_t)", i);
    }
  }
}

void TCalibrator::WriteGains(string fname)
{
  ofstream fout(fname.c_str(), ios::out);
  if(!fout){"[TCalibrator-E]: cannot open file: " << fname << endl; return; }
  for(int i=0; i<nhist; i++)
    fout << mean[i] << endl;
  fout.close();
  return;
}
