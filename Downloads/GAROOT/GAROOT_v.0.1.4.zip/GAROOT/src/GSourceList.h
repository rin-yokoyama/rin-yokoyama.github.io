#include"subfunctions.h"
#include"GSource.h"

class GSourceList
{
 protected:
  Int_t NSource;
  string* SourceName;
  string* SourceFile;
  void ReadListFile(string fname);
 public:
  GSourceList(string fname);
  virtual ~GSourceList(void);
  void List(void);
  string GetSource(Int_t s_num);
  Int_t GetNSource(void);
};
