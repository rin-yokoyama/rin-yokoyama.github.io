#include "TResFit.h"

TResFit::TResFit(void){}

TResFit::TResFit(TH2* fTH2)
{
  fTH2F = (TH2F*)fTH2;
}

TResFit::~TResFit(void){}

void TResFit::SetGraph(TGraph &ptr)
{
  ptr = fTResGraph;
}

TGraph* TResFit::PlotRes(Int_t Nsigma, Int_t rebinx, Double_t center, Double_t max)
{
  fTResGraph = new TGraph();
  *fTResGraph = Graph;
  TH2F* TH2Rebin = fTH2F->Clone();
  TH2Rebin->Rebin2D(rebinx,1);
  Int_t nx = TH2Rebin->GetNbinsX();
  for(int i=0; i<nx; i++){
    TH1D *TH1DSlice = TH2Rebin->ProjectionY("_py",i,i,"e");
    Int_t binlow = TH1DSlice->FindBin(center);
    Int_t binup = TH1DSlice->FindBin(max);
    Double_t dev = 0.0;
    Double_t num = 0.0;
    for(int j=binlow; j<binup; j++){
      num += TH1DSlice->GetBinContent(j);
      dev += TH1DSlice->GetBinContent(j)*pow(( TH1DSlice->GetBinCenter(j) - center ),2);
    }
    dev = sqrt(dev/(num-1));
    fTResGraph->SetPoint( i, TH2Rebin->GetBinCenter(i), dev*Nsigma );
    delete TH1DSlice;
  }
  return fTResGraph;
}

TGraph* TResFit::PlotZero(Double_t Offset, Double_t thresh, Int_t rebinx, Double_t gain, Double_t max)
{
  fTResGraph = new TGraph();
  *fTResGraph = Graph;
  TH2F* TH2Rebin = fTH2F->Clone();
  TH2Rebin->Rebin2D(rebinx,1);
  Int_t nx = TH2Rebin->GetNbinsX();
  for(int i=0; i<nx; i++){
    TH1D *TH1DSlice = TH2Rebin->ProjectionY("_py",i,i,"e");
    Int_t binlow = TH1DSlice->FindBin(0);
    Int_t binup = TH1DSlice->FindBin(max);
    Double_t dev = max;
    for(int j=binup; j>binlow; j--){
      if( TH1DSlice->GetBinContent(j) <= thresh )
	dev = TH1DSlice->GetBinCenter(j);
    }
    fTResGraph->SetPoint( i, TH2Rebin->GetBinCenter(i), gain*dev+Offset );
    delete TH1DSlice;
  }
  return fTResGraph;
}
