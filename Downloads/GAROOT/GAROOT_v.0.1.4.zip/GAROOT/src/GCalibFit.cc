#include "GCalibFit.h"

GCalibFit::GCalibFit(CalFuncType func_type)
{
  fGCalibFunc = new GCalibFunc();
  func_t = func_type;
  fit_n = 0;
}

GCalibFit::~GCalibFit(void){}

void GCalibFit::CalibFit(Int_t n, Double_t* x, Double_t* y, Double_t* xerror, Double_t* yerror)
{
  EvsCh = new TGraphErrors(n, x, y, xerror, yerror);
  Residual = new TGraphErrors(n);
  *Residual = Graph;
  fit = fGCalibFunc->CalibFunc(func_t);
  EvsCh->Fit(fit);
  for(int i=0; i<n; i++){
    Residual->SetPoint( i, y[i], fit->Eval(x[i]) - y[i] );
    Residual->SetPointError( i, yerror[i], fGCalibFunc->CalcResidualError(x[i],xerror[i],yerror[i], fit->GetParameters(),fit->GetParErrors(), func_t));
  }
  DrawResidual(fit_n);
  fit_n++;
}

void GCalibFit::DrawResidual(Int_t)
{
  Residual->Draw("AP");
  Emit("DrawResidual(Int_t)",fit_n);
}
