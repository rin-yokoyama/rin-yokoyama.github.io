#include "GSlewFit.h"

GSlewFit::GSlewFit(void){}

GSlewFit::GSlewFit(TH2* fTH2, string conf_f, Int_t h_num) : TH2MaxGraph(fTH2), TResFit(fTH2)
{
  hnum = h_num;
  ReadConf(conf_f);
  fTF1 = NULL;
}

GSlewFit::~GSlewFit(void){}

void GSlewFit::ReadConf(string f_name)
{
  ifstream fin(AppendMacroPath(f_name).c_str(), ios::in);
  if(!fin){
    cout << "[GSlewFit-E]: cannot open conf file: " << fname << endl;
    return;
  }
  istringstream oss;
  string str;
  getline( fin, str );
  oss.str(str);
  oss >> d_opt_hist;
  getline( fin, str );
  oss.str(str);
  oss >> d_opt_graph;
  getline( fin, str );
  xtitle = str.substr(0,str.find_first_of("//"));
  getline( fin, str );
  ytitle = str.substr(0,str.find_first_of("//"));
  fTH2F->GetXaxis()->SetTitle(xtitle.c_str());
  fTH2F->GetYaxis()->SetTitle(ytitle.c_str());
  getline( fin, str );
  oss.str(str);
  oss >> f_type;
  GSlewFunc *fGSlewFunc = new GSlewFunc("GSlewFitTmp");
  npar = fGSlewFunc->CalibFunc(f_type)->GetNpar();
  delete fGSlewFunc;
  init_param = new Double_t[npar];
  for(int i=0; i<npar; i++){
      getline( fin, str );
      oss.str(str);
      oss >> init_param[i];
  }
  fin.close();
}

void GSlewFit::SlewFit()
{
  GSlewFunc *fGSlewFunc = new GSlewFunc("GSlew",hnum);
  TAxis *XAxis = fTH2F->GetXaxis();
  fGSlewFunc->SetRange( XAxis->GetBinCenter(XAxis->GetFirst()), XAxis->GetBinCenter(XAxis->GetLast()) );
  fTF1 = fGSlewFunc->CalibFunc(f_type);
  fTF1->SetParameters(init_param);
  fTGraph->Fit(fTF1);
  return;
}

void GSlewFit::Fit()
{
  fTGraph->Fit(fTF1);
}

void GSlewFit::Draw(void)
{
  fTH2F->Draw(d_opt_hist.c_str());
  if( ifgconst )
    fTGraph->Draw(d_opt_graph.c_str());
}

TF1* GSlewFit::GetTF1(void)
{
  return fTF1;
}

Int_t GSlewFit::GetNpar(void)
{
  return npar;
}

TGraph* GSlewFit::PlotZero(Double_t Offset, Double_t thresh, Int_t rebinx, Double_t gain, Double_t max)
{
  TResFit::PlotZero(Offset, thresh, rebinx, gain, max);
  fTGraph = fTResGraph;
  ifgconst = 1;
  return fTGraph;
}
