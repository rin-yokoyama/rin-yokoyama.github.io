#include <TGraphErrors.h>
#include <RQ_OBJECT.h>
#include "CalibFunctions.h"
#include "Styles.h"

class GCalibFit
{
  RQ_OBJECT("GCalibFit")
 protected:
  Int_t fit_n;
  GCalibFunc* fGCalibFunc;
  TF1* fit;
  TGraphErrors* EvsCh;
  TGraphErrors* Residual;
  CalFuncType func_t;
  void DrawResidual(Int_t);
 public:
  GCalibFit(CalFuncType func_type);
  ~GCalibFit(void);
  void CalibFit(Int_t n, Double_t* x, Double_t* y, Double_t* xerror, Double_t* yerror);
};
