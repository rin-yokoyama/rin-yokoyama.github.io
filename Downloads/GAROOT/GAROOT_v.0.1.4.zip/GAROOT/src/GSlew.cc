#include "GSlew.h"

GSlew::GSlew(Int_t nhist, TH2F** fTH2F)
{
  try{
    n_hist = nhist;
    fTCanvas = new TCanvas("Gcanv","GSlew",CANV_W,CANV_H);
    fGSlewFit = new GSlewFit[n_hist];
    for(int i=0; i<n_hist; i++)
      fGSlewFit[i] = new GSlewFit(fTH2F[i], SLEW_CONF, i);
    hid = 0;
    ht(0);
    mode = 0;
    gStyle->SetOptFit();
    fGSlewFit[0]->Draw();
    ConnectShortCut();
  }
  catch(bad_alloc){
    cout << "[GSlew-E]: Exeption bad_alloc." << endl;
    throw;
  }
}

GSlew::~GSlew(void){}

Int_t  GSlew::CheckHN(Int_t hn)
{
  if( (hn<0) || (hn>=n_hist) )
    return 0;
  else
    return 1;
}

void GSlew::ConnectShortCut()
{
  fTCanvas->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "GSlew", this, "ExecuteShortCut(Int_t, Int_t, Int_t, TObject*)");
}

void GSlew::Expand(Double_t x, Double_t y)
{
  if(!mode){
    xmin_com = x;
    ymin_com = y;
    mode = 2;
    return;
  }
  else if(mode == 2){
    xmax_com = x;
    ymax_com = y;
    mode = 0;
    zoom(xmin_com,xmax_com,ymin_com,ymax_com);
    return;
  }
}

void GSlew::mg(Int_t rebinx, Int_t rebiny)
{
  for(int i=0; i<n_hist; i++){
    fGSlewFit[i]->MaxGraph(rebinx, rebiny);
    fGSlewFit[i]->Draw();
  }
}

void GSlew::rmg(Int_t rebinx, Int_t rebiny, Double_t ylow, Double_t yup)
{
  fGSlewFit[hid]->MaxGraph(rebinx, rebiny, ylow, yup);
  fGSlewFit[hid]->Draw();
  cout << "reconstructed fTGraph of fGSlewFit[" << hid << "]." << endl;
}

void GSlew::ht(Int_t id)
{
  if(CheckHN(id)){ hid = id; }
  fGSlewFit[hid]->Draw();
}

void GSlew::hn()
{
  if(hid < n_hist-1)
    hid++;
  fGSlewFit[hid]->Draw();
  fTCanvas->Update();
}

void GSlew::hb()
{
  if(0 < hid)
    hid--;
  fGSlewFit[hid]->Draw();
  fTCanvas->Update();
}

void GSlew::zoom(Double_t xlow, Double_t xup, Double_t ylow, Double_t yup)
{
  for(int i=0; i<n_hist; i++){
    fGSlewFit[i]->GetTH2()->SetAxisRange(xlow,xup);
    fGSlewFit[i]->GetTH2()->SetAxisRange(ylow,yup,"Y");
  }
  fGSlewFit[hid]->Draw();
  fTCanvas->Update();
}

void GSlew::ft()
{
  for(int i=0; i<n_hist; i++){
    fGSlewFit[i]->SlewFit();
  }
}

void GSlew::tr(Double_t Offset, Double_t thresh, Int_t rebinx, Double_t gain, Double_t max)
{
  for(int i=0; i<n_hist; i++){
    fGSlewFit[i]->GSlewFit::PlotZero(Offset, thresh, rebinx, gain, max);
    fGSlewFit[i]->Draw();
  }
  return;
}

void GSlew::FixParam(Int_t ipar, string parfile)
{
  ifstream fin(parfile.c_str(), ios::in);
  if(!fin){ cout << "[GSlew-E]: cannot open file: " << parfile << endl; return; }
  for(int i=0; i<n_hist; i++){
    Double_t par;
    fin >> par;
    fGSlewFit[i]->GetTF1()->FixParameter(ipar,par);
    fGSlewFit[i]->Fit();
  }
  return;
}

void GSlew::WriteCSV(string fname)
{
  ofstream fout(fname.c_str(),ios::out);
  fout << "hist_N, Chisquare, ";
  for(int i=0; i<fGSlewFit[0]->GetNpar(); i++)
    fout << fGSlewFit[0]->GetTF1()->GetParName(i) << ", " << "error, ";
  fout << endl;
  for(int i=0; i<n_hist; i++){
    fout << i << ", " << fGSlewFit[i]->GetTF1()->GetChisquare() << ", ";
    for(int j=0; j<fGSlewFit[i]->GetNpar(); j++){
      fout << fGSlewFit[i]->GetTF1()->GetParameter(j) << ", ";
      fout << fGSlewFit[i]->GetTF1()->GetParError(j) << ", ";
    }
    fout << endl;
  }
  fout.close();
  return;
}

void GSlew::WriteROOTFile(string fname, Option_t* opt)
{
  TFile *file = new TFile(fname.c_str(), opt);
  for(int i=0; i<n_hist; i++){
    fGSlewFit[i]->GetTH2()->Write();
    ostringstream oss;
    oss << "graph" << i;
    fGSlewFit[i]->GetTGraph()->Write(oss.str().c_str());
    if(fGSlewFit[i]->GetTF1() != NULL )
      fGSlewFit[i]->GetTF1()->Write();
  }
  file->Close();
}

void GSlew::PrintAll(string fname)
{
  fTCanvas->Print(fname.append("[").c_str());
  for(int i=0; i<n_hist; i++){
    ht(i);
    fTCanvas->Print(fname.c_str());
  }
  fTCanvas->Print(fname.append("]").c_str());
  return;
}
