#include<iostream>
#include<fstream>
#include"subfunctions.h"

//class for the reference of gamma-ray energies
class GSource
{
 protected:
  UInt_t HalfLife;  //half life in sec
  Int_t NGamma;
  Double_t *Energy; //array of gamma-ray energies
  Double_t *Error; //array of errors of the gamma-ray energy
  Double_t *RelInt; //array of relative intensities
  Double_t *RelIntE; //array of errors of the relative intensities
  void ReadSourceFile(string s_fname);

 public:
  GSource(void);
  GSource(string s_fname);
  virtual ~GSource(void);
  Double_t* GetEnergy(void);
  Double_t GetEnergy(Int_t i_gamma);
  Double_t* GetError(void);
  Double_t GetError(Int_t i_gamma);
  void ListEnergy(void);
  Int_t GetNGamma(void);
};
