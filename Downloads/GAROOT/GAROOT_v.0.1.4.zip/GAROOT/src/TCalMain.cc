#include "ROOTFileReader.h"
#include "TCalibrator.h"
#include "PSPrinter.h"
#include "Styles.h"
#include <TH1.h>
#include <TList.h>
#include <TKey.h>

TH1F** hist;
TCalibrator* g;

void TCalMain(string fname, string psfname, string prmfname)
{
  //reads 1D histograms from file.
  if(fname == "_file0"){
    fname = _file0->GetPath();
    fname = fname.substr(0, fname.size() - 2);
  }
  file = new ROOTFileReader(fname);
  Int_t n_obj = file->ReadObj("TH1","TH2");
  hist = new TH1F[n_obj];
  for(int i=0; i<n_obj; i++){
    hist[i] = (TH1F*)file->GetObj(i);
    //    *(hist+i) = GHistLine;
    //    *(hist+i) = GHistFill;
  }

  //asks for the interval time of the pulse from time calibrator
  Double_t interval;
  cout << "Input the interval time of the pulses." << endl;
  cout << "Interval: ";
  cin >> interval;

  g = new TCalibrator(hist, n_obj, interval);
  PSPrinter *ps = new PSPrinter(psfname, 2*n_obj);
  g->Connect("SearchPeak(Int_t)", "PSPrinter", ps, "PrintPage(Int_t)");
  g->SearchPeak(1);
  g->Disconnect();
  ps->Clear();
  g->Connect("Calibrate(Int_t)", "PSPrinter", ps, "PrintPage(Int_t)");
  g->Calibrate(1);
  g->Disconnect();
  g->WriteGains(prmfname);
  return;
}
