#include<iostream>
#include<TF1.h>

class GLineInv : public TF1
{
 protcted:
  Double_t par[2];
 public:
  GLineInv(Double_t p0, Double_t p1, string name, Double_t xmin = 0, Double_t xmax = 10000);
  ~GLineInv(void);
};
