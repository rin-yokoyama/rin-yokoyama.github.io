#include"GAutoFit.h"

GAutoFit::GAutoFit(string confname)
{
  ReadConf(confname);
}

GAutoFit::~GAutoFit(void){}

void GAutoFit::ReadConf(string confname)
{
  try{
    string buf;
    ifstream fin(confname.c_str(), ios::in);
    if(!fin){ string em = "cannot open file"; throw em.append(confname); }
    nfit = 0;
    while(!fin.eof()){
      getline( fin, buf );
      nfit++;
    }
    npeak = new Int_t[nfit];
    fixprmfile = new string[nfit];
    xmin = new Double_t[nfit];
    xmax = new Double_t[nfit];
    peak = new Double_t*[nfit];
    for(int i=0; i<nfit; i++){
      fin >> npeak[i];
      fin >> fixprmfile[i];
      fin >> xmin[i];
      fin >> xmax[i];
      peak[i] = new Double_t[npeak[i]];
      for(int j=0; j<npeak[i]; j++)
	fin >> peak[i][j];
    }
    fin.close();
  }
  catch(bad_alloc){
    cout << "[GAutoFit-E] : Exception bad_alloc." << endl;
    throw;
  }
  catch(string e){
    cout << "[GAutoFit-E] : " << e << endl;
    throw 1;
  }
}

void GAutoFit::AutoFit(TH1* Hist)
{
  fGPeakFit = new GPeakFit((TH1F*)Hist, nfit);
  for(int i=0; i<nfit; i++){
    Double_t *mkpos[2][NM_MAX];
    mkpos[0][0] = xmin[i];
    mkpos[1][0] = Hist->GetBinContent( Hist->FindBin( xmin[i] ) );
    mkpos[0][1] = xmax[i];
    mkpos[1][1] = Hist->GetBinContent( Hist->FindBin( xmax[i] ) );
    for(int j=0; j<npeak[i]; j++){
      mkpos[0][j+2] = peak[i];
      mkpos[1][j+2] = Hist->GetBinContent( Hist->FindBin( peak[i] ) );
    }
    fGPeakFit->SetFitting(npeak[i], mkpos, fitnum[i] );
    fGPeakFit->FixParams(fixprmfile[i]);
    fGPeakFIt->GFit();
  }
}
