#include <TF2.h>
using namespace std;

Int_t* ACorrReturn;

class ACorresponder
{
 protected:
  Int_t nA;
  Int_t nB;
  Double_t* Array;
  TF2* fTF2;
  Double_t MinDev(Double_t *x, Double_t *par );
 public:
  ACorresponder(Double_t* ArrayA, Double_t* ArrayB, Int_t nArrayA, Int_t nArrayB);
  ~ACorresponder(void);
  Int_t* Correspond(Double_t& x, Double_t& y, Double_t gain, Double_t ROffSet = 10,Int_t Npx = 100, Int_t Npy = 100);
};
