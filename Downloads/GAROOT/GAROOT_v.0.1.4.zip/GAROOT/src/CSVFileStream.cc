#include"CSVFileStream.h"

CSVFileStream::CSVFileStream(string fname, int read_only, int buf_col, int buf_raw)
{
  try{
    ro = read_only;
    nraw = buf_raw;
    ncol = buf_col;
    filename = fname;
    buffer = new string*[nraw];
    for(int i=0; i<nraw; i++){
      buffer[i] = new string[ncol];
      for(int j=0; j<ncol; j++)
	buffer[i][j] = "";
    }
    OpenFile();
  }
  catch(bad_alloc){
    cout << "[CSVFileStream-E]: Exception bad_alloc." << endl;
    throw;
  }
}

CSVFileStream::~CSVFileStream(void)
{
  file.close();
}

void CSVFileStream::OpenFile()
{
    if(ro)
      file.open(filename.c_str(), ios::in);
    else
      file.open(filename.c_str(), ios::in | ios::out | ios::trunc);
    if(!file){ cout << "[CSVFileStream-E]: cannot open file: " << filename << endl; }
}

void CSVFileStream::CloseFile()
{
  file.close();
}

int CSVFileStream::chk_ro()
{
  if(ro){
    cout << "[CSVFileStream-E]: The stream is opened in read only mode" << endl;
    return 1;
  }
  return 0;
}

int CSVFileStream::chk_num(int raw, int col)
{
  if( (raw < 0) || (nraw-1 < raw) ){
    cout << "[CSVFileStream-E]: invalid raw number." << endl;
    return 1;
  }
  if( (col < 0) || (ncol-1 < col) ){
    cout << "{CSVFileStream-E]: invalid col number." << endl;
    return 1;
  }
  return 0;
}

void CSVFileStream::SetLine(string *line, int raw)
{
  if(chk_num(raw)){ return; }
  for(int i=0; i<ncol; i++){
    buffer[raw][i] = line[i];
  }
}

void CSVFileStream::SetString(string content, int col, int raw)
{
  buffer[raw][col] = content;
}

void CSVFileStream::SetInt(int content, int col, int raw)
{
  if(chk_num(raw,col)){ return; }
  ostringstream oss;
  oss.str("");
  oss << content;
  buffer[raw][col] = oss.str();
}

void CSVFileStream::SetDouble(double content, int col, int raw)
{
  if(chk_num(raw,col)){ return; }
  ostringstream oss;
  oss.str("");
  oss << content;
  buffer[raw][col] = oss.str();
}

void CSVFileStream::WriteLine(int raw)
{
  if(chk_ro()){ return; }
  if(chk_num(raw)){ return; }
  for(int i=0; i<ncol; i++){
    buffer[raw][i] = buffer[raw][i].append(", ");
    file << buffer[raw][i];
  }
  file << endl;
}

void CSVFileStream::WriteBuf()
{
  if(chk_ro()){ return; }
  for(int i=0; i<nraw; i++){
    WriteLine(i);
  }
  ClearBuf();
}

void CSVFileStream::ClearBuf()
{
  for(int i=0; i<nraw; i++){
    for(int j=0; j<ncol; j++)
      buffer[i][j] = "";
  }
}

void CSVFileStream::ReadtoBuf()
{
  for(int i=0; i<nraw; i++){
    string line;
    getline(file, line);
    if(!line.size()){ return; }
    for(size_t pos=0;(pos != string::npos) && (pos<line.size()-1); pos++){
      pos = line.find(',', pos);
      line.replace(pos, 1, " ");
    }
    istringstream iss(line);
    for(int j=0; (j<ncol) && !file.eof(); j++){
      iss >> buffer[i][j];
    }
  }
  return;
}

string CSVFileStream::GetString(int col, int raw)
{
  if(chk_num(raw,col)){ return ""; }
  return buffer[raw][col];
}

int CSVFileStream::GetInt(int col, int raw)
{
  if(chk_num(raw,col)){ return 0; }
  istringstream iss(buffer[raw][col]);
  int buf = 0;
  iss >> buf;
  return buf;
}
double CSVFileStream::GetDouble(int col, int raw)
{
  if(chk_num(raw,col)){ return 0; }
  istringstream iss(buffer[raw][col]);
  double buf = 0;
  iss >> buf;
  return buf;
}

fstream* CSVFileStream::GetFileStream(void)
{
  return file;
}
