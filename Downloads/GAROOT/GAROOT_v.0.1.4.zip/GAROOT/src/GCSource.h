#include "GSource.h"
#include <TDatime.h>

class GCSource : public GSource
{
 protected:
  string SName;
  string sourcefile; //name of the source file
  TDatime *RefDate; //reference date for the intensity
  TDatime *CurDate; //current date (measurement)
  Double_t RefInt; //intensity at the reference date
  Double_t RefIntError; //error of the intensity
  Double_t CurInt; //current intensity
  
  void ReadCSourceFile(string fname);

 public:
  GCSource(string sc_fname);
  virtual ~GCSource(void);
  void SetDate(Int_t yyyy, Int_t mm, Int_t dd, Int_t hour = 0, Int_t min = 0, Int_t sec = 0);
  Double_t GetIntensity(Int_t i_gamma);
  Double_t GetIntError(Int_t i_gamma);
};
