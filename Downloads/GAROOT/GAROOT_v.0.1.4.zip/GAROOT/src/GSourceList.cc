#include"GSourceList.h"

GSourceList::GSourceList(string fname)
{
  ReadListFile(fname);
}

GSourceList::~GSourceList(void){}

void GSourceList::ReadListFile(string fname)
{
  ifstream fin(fname.c_str(), ios::in);
  if(!fin){
    cout << "[GSourceList-E]: cannot open list file :" << fname << endl;
    NSource = 0;
    return;
  }
  fin >> NSource;
  SourceName = new string[NSource];
  SourceFile = new string[NSource];
  for(int i=0; i<NSource; i++){
    fin >> SourceName[i];
    fin >> SourceFile[i];
  }  
}

void GSourceList::List(void)
{
  cout << "source#\tname\n";
  for(int i=0; i<NSource; i++){
    cout << i << "\t" << SourceName[i] << endl;
  }
}

string GSourceList::GetSource(Int_t s_num)
{
  return AppendMacroPath(SourceFile[s_num]);
}

Int_t GSourceList::GetNSource(void)
{
  return NSource;
}
