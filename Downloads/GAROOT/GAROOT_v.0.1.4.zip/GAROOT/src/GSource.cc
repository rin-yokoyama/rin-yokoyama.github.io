#include"GSource.h"

GSource::GSource(void){}

GSource::GSource(string s_fname)
{
  ReadSourceFile(s_fname);
}

GSource::~GSource(void)
{
}

void GSource::ReadSourceFile(string s_fname)
{
  ifstream fin(AppendMacroPath(s_fname).c_str(), ios::in);
  if(!fin){
    cout << "[GSource-E]: cannot open source file : " << s_fname << endl;
    NGamma = 0;
    return;
  }
  HalfLife = new TDatime();
  Int_t day;
  istringstream iss;
  string buf;
  getline(fin, buf);
  iss.str(buf);
  iss >> day;
  HalfLife = day*24*3600;
  getline(fin, buf);
  iss.str(buf);
  iss >> NGamma;
  Energy = new Double_t[NGamma];
  Error = new Double_t[NGamma];
  RelInt = new Double_t[NGamma];
  RelIntE = new Double_t[NGamma];
  for(int i=0; i<NGamma; i++){
    getline(fin, buf);
    istringstream iss2(buf);
    iss2 >> Energy[i];
    iss2 >> Error[i];
    iss2 >> RelInt[i];
    iss2 >> RelIntE[i];
  }
}

Double_t* GSource::GetEnergy()
{
  return Energy;
}

Double_t GSource::GetEnergy(Int_t i_gamma)
{
  return Energy[i_gamma];
}

Double_t* GSource::GetError()
{
  return Error;
}

Double_t GSource::GetError(Int_t i_gamma)
{
  return Error[i_gamma];
}

void GSource::ListEnergy(void)
{
  cout << "#\tenergy\n";
  for(int i=0; i<NGamma; i++){
    cout << i << "\t" << Energy[i] << endl;
  }
}

Int_t GSource::GetNGamma(void)
{
  return NGamma;
}
