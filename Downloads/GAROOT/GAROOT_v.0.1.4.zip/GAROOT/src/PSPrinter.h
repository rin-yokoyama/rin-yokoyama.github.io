#include<iostream>
#include<TCanvas.h>
#include<RQ_OBJECT.h>
using namespace std;

//this class will print ps files when PrintPage(Int_t) recieve a signal
class PSPrinter : public TCanvas
{
  RQ_OBJECT("TCanvas")
 protected:
  string filename;
  Int_t npage; //number of the pages
 public:
  PSPrinter(string fname, Int_t n_page, Int_t width = 640, Int_t height = 360);
  virtual ~PSPrinter(void);
  void PrintPage(Int_t);
};
