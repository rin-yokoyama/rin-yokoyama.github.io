#include<TH2MaxGraph.h>

TH2MaxGraph::TH2MaxGraph(TH2 *fTH2)
{
  fTH2F = (TH2F*)fTH2;
  ifgconst = 0;
}

TH2MaxGraph::~TH2MaxGraph(void){}

TGraph* TH2MaxGraph::MaxGraph(Int_t rebinx, Int_t rebiny, Double_t ylow, Double_t yup)
{
  if((ylow==0)&&(yup==0)){
    ymax = fTH2F->GetYaxis()->GetBinCenter( fTH2F->GetYaxis()->GetLast() );
    ymin = fTH2F->GetYaxis()->GetBinCenter( fTH2F->GetYaxis()->GetFirst() );
    ylow = ymin;
    yup = ymax;
  }
  if((rebinx==0)&&(rebiny==0)){
    rebinx = rbinx;
    rebiny = rbiny;
  }
  TH2F* TH2Rebin = (TH2F*)fTH2F->Clone();
  TH2Rebin->Rebin2D(rebinx, rebiny);
  Int_t nx = TH2Rebin->GetNbinsX();
  fTGraph = new TGraph();
  *fTGraph = Graph;
  for(int i=0; i<nx; i++){
    TH1D *TH1DSlice = TH2Rebin->ProjectionY("_py",i,i,"e");
    Double_t x = TH2Rebin->GetBinCenter(i);
    Double_t y = TH1DSlice->GetBinCenter( TH1DSlice->GetMaximumBin() );
    if((ylow<y)&&(y<yup))
      fTGraph->SetPoint(i,x,y);
    delete TH1DSlice;
  }
  rbinx = rebinx;
  rbiny = rebiny;
  delete TH2Rebin;
  ifgconst = 1;
  return (TGraph*)fTGraph->Clone();
}

TH2F* TH2MaxGraph::GetTH2(void)
{
  return fTH2F;
}

TGraph* TH2MaxGraph::GetTGraph(void)
{
  return fTGraph;
}
