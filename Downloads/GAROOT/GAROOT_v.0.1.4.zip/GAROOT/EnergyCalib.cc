void EnergyCalib(string fname, string ofname = "calprm.txt", string psname = "residuals.ps")
{
  gROOT->ProcessLine(".L GAROOT/src/setgaroot.h");
  gROOT->ProcessLine(".L GAROOT/src/subfunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/AOrder.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSource.cc");
  gROOT->ProcessLine(".L GAROOT/src/GSourceList.cc");
  gROOT->ProcessLine(".L GAROOT/src/PSPrinter.cc");
  gROOT->ProcessLine(".L GAROOT/src/CSVFileStream.cc");
  gROOT->ProcessLine(".L GAROOT/src/GfROOTCSVReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/ACorresponder.cc");
  gROOT->ProcessLine(".L GAROOT/src/CalibFunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/GCalibFit.cc");
  gROOT->ProcessLine(".L GAROOT/src/ECalMain.cc");
  ECalMain(fname, ofname, psname);
}
