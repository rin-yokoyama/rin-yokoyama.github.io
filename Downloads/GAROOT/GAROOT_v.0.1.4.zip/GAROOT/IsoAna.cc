#define HSTMAX 256
#define FITMAX 256
#define PKCTMAX 16
#define MKN 3

class TIsoAna{
 private:
  TH2F *ETmat;
  TH1F *hist[HSTMAX];
  Int_t hn, fEn, fTn, pkn, ctn;
  Color_t hl_col, hf_col;
  Double_t pk[2][PKCTMAX], ct[2][PKCTMAX];
  TMarker *mk[MKN];
 public:
  TCanvas *canv;
  TF1 *fitE[FITMAX];
  TF1 *fitT[FITMAX];
  TF1 *base;
  TIsoAna(TH2F* ETin);
  ~TIsoAna(void);
  void dmk(void);
  void mkc(void);
  void draw(int hid = -1);
  void sethcol(Color_t lcol, Color_t fcol);
  void setpk(Double_t pklow = 0, Double_t pkup = 0);
  void setct(Double_t pklow = 0, Double_t pkup = 0);
  TH1F* prE(Double_t tlow = 0, Double_t tup = 0);
  TH1F* prT(void);
  void nfE(Int_t fixp = 1);
  void nfT(Int_t fixp = 1, Option_t *op = "");
};

TIsoAna::TIsoAna(TH2F* ETin){
  ETmat = ETin;
  hn = -1;
  pkn = -1;
  ctn = -1;
  fEn = -1;
  fTn = -1;
  hl_col = kCyan + 1;
  hf_col = kCyan + 1;
  for(int i=0; i<MKN; i++){
    mk[i] = new TMarker(0,0,23);
    mk[i]->SetMarkerColor(i+2);
  }
  base = new TF1("base","pol0(0)",0,30000);
  base->SetLineColor(4);
  base->SetLineStyle(3);
  canv = new TCanvas("canv","canv",0,0,640,500);
  ETmat->SetMarkerColor(hl_col);
  ETmat->Draw("");
  //gStyle->SetOptStat(0);
}

TIsoAna::~TIsoAna(void){

}

void TIsoAna::dmk(void){
  if(hn<0){
    cout << "No TH1 has been created." << endl;
    return;
  }
  else{
    for(int i=0; i<MKN; i++){
      mk[i]->SetX(hist[hn]->GetBinCenter(hist[hn]->GetXaxis()->GetFirst()));
      mk[i]->SetY(hist[hn]->GetMinimum());
      mk[i]->Draw("");
    }
  }
  return;
}

void TIsoAna::mkc(void){
  cout << "X\tY" << endl;
  for(int i=0; i<MKN; i++){
    cout << mk[i]->GetX() << "\t" << mk[i]->GetY() << endl;
  }
}

void TIsoAna::draw(int hid){
  if( hid < 0 ){
    ETmat->SetMarkerColor(hl_col);
    ETmat->Draw("");
  }
  else if( hid > hn ){
    cout << "hist" << hid << "does not exist." << endl;
  }
  else{
    hist[hid]->SetLineColor(hl_col);
    hist[hid]->SetFillColor(hf_col);
    hist[hid]->Draw("");
  }
}

void TIsoAna::sethcol(Color_t lcol, Color_t fcol){
  hl_col = lcol;
  hf_col = fcol;
  draw(hn);
}

void TIsoAna::setct(Double_t ctlow, Double_t ctup){
  ctn++;
  if( (ctlow==0) && (ctup==0) ){
    ctlow = mk[MKN-2]->GetX();
    ctup = mk[MKN-1]->GetX();
  }
  ct[0][ctn] = ctlow;
  ct[1][ctn] = ctup;
  cout << "The following range has been added as a Compton part:" << endl;
  cout << ct[0][ctn] << "\t" << ct[1][ctn] << endl;
  return;
}

void TIsoAna::setpk(Double_t pklow, Double_t pkup){
  pkn++;
  if( (pklow == 0) && (pkup == 0) ){
    pklow = mk[MKN-2]->GetX();
    pkup = mk[MKN-1]->GetX();
  }
  pk[0][pkn] = pklow;
  pk[1][pkn] = pkup;
  cout << "The following range has been added as a peak:" << endl;
  cout << pk[0][pkn] << "\t" << pk[1][pkn] << endl;
  return;
}

TH1F* TIsoAna::prE(Double_t tlow, Double_t tup){
  hn++;
  ostringstream oss;
  oss.str("");
  oss << "hist" << hn;
  cout << oss.str() <<"has been created." << endl;
  hist[hn] = (TH1F*)ETmat->ProjectionX(oss.str().c_str(),ETmat->GetYaxis()->FindBin(tlow),ETmat->GetYaxis()->FindBin(tup));
  hist[hn]->SetXTitle("Energy (keV)");
  hist[hn]->SetYTitle("Count");
  draw(hn);
  return hist[hn];
}

TH1F* TIsoAna::prT(void){
  TH1D* h_tmp;
  if( (pkn<0) ){
    cout << "please set the ranges of peaks ahead." << endl;
  }
  else{
    hn++;
    ostringstream oss;
    oss.str("");
    oss << "hist" << hn;
    cout << oss.str() <<"has been created." << endl;
    h_tmp = ETmat->ProjectionY(oss.str().c_str(),hist[hn-1]->FindBin(pk[0][0]),hist[hn-1]->FindBin(pk[1][0]));
    Int_t nbin = h_tmp->GetNbinsX();
    Double_t *Err = new Double_t[nbin];
    for(int k=0; k<nbin; k++){
      Double_t cnt = h_tmp->GetBinContent(k);
      Err[k] = sqrt(cnt);
    }
    for(int i=1; i<pkn+1; i++){
      TH1F* prtmp = (TH1F*)ETmat->ProjectionY("tmp",hist[hn-1]->FindBin(pk[0][i]),hist[hn-1]->FindBin(pk[1][i]));
      h_tmp->Add(prtmp);
      for(int k=0; k<nbin; k++){
	Double_t cnt = prtmp->GetBinContent(k);
	Double_t prEr = sqrt(cnt);
	if(cnt==0)
	  prEr = 1;
	Err[k] = sqrt(Err[k]*Err[k] + prEr*prEr);
      }
    }
    for(int k=0; k<nbin; k++){
      Double_t cnt = h_tmp->GetBinContent(k);
      if(cnt==0)
	Err[k] = 1;
    }
    TH1F* htmp2 = h_tmp->Clone();
    for(int i=0; i<ctn+1; i++){
      Double_t coef = 0;
      for(int j=0; j<pkn+1; j++)
	coef += pk[1][j] - pk[0][j];
      coef = -1.0*coef / ( ct[1][i] - ct[0][i] );
      cout << coef << endl;
      TH1F *prtmp = (TH1F*)ETmat->ProjectionY("tmp",hist[hn-1]->FindBin(ct[0][i]),hist[hn-1]->FindBin(ct[1][i]));
      h_tmp->Add( prtmp, coef);   
      for(int k=0; k<nbin; k++){
	Double_t cnt = prtmp->GetBinContent(k);
	Double_t prEr = sqrt(cnt);
	Err[k] = sqrt(Err[k]*Err[k] + coef*coef*prEr*prEr);
      }      
    }
  }
  h_tmp->SetError(Err);
  hist[hn] = (TH1F*)h_tmp;
  hist[hn]->SetXTitle("Time (ns)");
  hist[hn]->SetYTitle("Count");
  pkn = -1;
  ctn = -1;
  draw(hn);
  return hist[hn];
}

void TIsoAna::nfE(Int_t fixp){
  if(hn<0){
    cout << "No TH1 has been created." << endl;
    return;
  }
  fEn++;
  ostringstream oss;
  oss.str("");
  oss << "fit" << fEn;
  cout << oss.str() << "has been created." << endl;
  rangemin = ETmat->GetXaxis()->GetXmin();
  rangemax = ETmat->GetXaxis()->GetXmax();
  fitE[fEn] = new TF1(oss.str().c_str(),"pol2(0) + [6]*gaus(3)/([5]*sqrt(2*TMath::Pi())) + (1-[6])*[3]*exp((x-[4])/[7])*TMath::Erfc((x-[4])/(sqrt(2)*[5]) + [5]/(sqrt(2)*[7])) + [3]*[8]*TMath::Erfc((x-[4])/(sqrt(2)*[5]))",rangemin, rangemax);
  fitE[fEn]->SetParNames("bg0", "bg1", "bg2", "area", "center", "sigma", "R", "beta", "step");
  fitE[fEn]->SetParameters( 10, -0.01, 0, mk[MKN-3]->GetY(), mk[MKN-3]->GetX(), 1.0, 0, 5, 0);
  fitE[fEn]->SetParLimits( 5, 0, 1000);
  fitE[fEn]->SetLineWidth(1);
  fitE[fEn]->SetLineColor(2);
  fitE[fEn]->SetNpx(1000);
  gStyle->SetOptFit();
  if(fixp){
    fitE[fEn]->FixParameter(2,0);
    fitE[fEn]->FixParameter(6,1);
    fitE[fEn]->FixParameter(7,1);
    fitE[fEn]->FixParameter(8,0);
  }
  hist[hn]->Fit(fitE[fEn],"","",mk[MKN-2]->GetX(),mk[MKN-1]->GetX());
  return;
}

void TIsoAna::nfT(Int_t fixp, Option_t *op){
  if(hn<0){
    cout << "No TH1 has been created." << endl;
    return;
  }
  fEn++;
  ostringstream oss;
  oss.str("");
  oss << "fit" << fEn;
  cout << oss.str() << "has been created." << endl;
  Double_t rangemin = ETmat->GetXaxis()->GetXmin();
  Double_t rangemax = ETmat->GetXaxis()->GetXmax();
  fitE[fEn] = new TF1(oss.str().c_str(),"[0]*pow(0.5, x/[1]) + [2]",rangemin,rangemax);
  fitE[fEn]->SetParNames("I0", "T1/2", "base line");
  fitE[fEn]->SetParameters( 100, 500, 0 );
  fitE[fEn]->SetLineWidth(1);
  fitE[fEn]->SetLineColor(2);
  fitE[fEn]->SetNpx(1000);
  gStyle->SetOptFit(1);
  if(fixp){
    fitE[fEn]->FixParameter(2,0);
  }
  hist[hn]->Fit(fitE[fEn],op,"",mk[MKN-2]->GetX(),mk[MKN-1]->GetX());
  if(!fixp){
    base->SetParameter(0,fitE[fEn]->GetParameter(2));
    //base->SetRange(rangemin,rangemax);
    base->Draw("same");
  }
  return;
}
