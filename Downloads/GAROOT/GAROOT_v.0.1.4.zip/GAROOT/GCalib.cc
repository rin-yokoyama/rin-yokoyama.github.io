#include<TROOT.h>


void GCalib(string pfname, string rfname = "", Int_t nbin = 4000, Int_t hid0 = 0, Int_t hidn = -1)
{
  gROOT->ProcessLine(".L GAROOT/src/setgaroot.h");
  gROOT->ProcessLine(".L GAROOT/src/subfunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/ROOTFileReader.cc");
  gROOT->ProcessLine(".L GAROOT/src/CalibFunctions.cc");
  gROOT->ProcessLine(".L GAROOT/src/GCalibrator.cc");
  gROOT->ProcessLine(".L GAROOT/src/GCalibManager.cc");
  gROOT->ProcessLine(".L GAROOT/src/GCalibMain.cc");
  GCalibMain(rfname, pfname, nbin, hid0, hidn);
}
