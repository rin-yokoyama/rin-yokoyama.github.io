#include "GPeakFitBase.h"

GPeakFitBase::GPeakFitBase(TH1F* hist, Int_t n_fit):TH1F(*(TH1F*)hist->Clone())
{
  if(n_fit < 0)
    nfit = dNFit;
  else
    nfit = n_fit;
  fn = -1;
  ConstN(nfit);
}

GPeakFitBase::~GPeakFitBase(void){}

Int_t GPeakFitBase::CheckFN(Int_t fitn)
{
  if(fitn < 0 || fitn > nfit)
    return 0;
  else
    return 1;
}

TF1* GPeakFitBase::GetTF1(Int_t fitn)
{
  if(CheckFN(fitn))
    return fTF1[fitn];
  else
    return fTF1[fn];
}

TF1* GPeakFitBase::ConstTF1(string f_name, Double_t xmin, Double_t xmax)
{
  TF1* func;
  //construction of TF1
  func = new TF1(f_name.c_str(), "pol1(0)+gaus(2)", xmin, xmax);

  //setting parameter names
  func->SetParNames("bg0","bg1","area","center","sigma");
  for(int i=0; i<5; i++)
    func->SetParameter(i,1.0);
  return (TF1*)func->Clone();
}

void GPeakFitBase::ConstN(Int_t n)
{
  fn++;
  ostringstream oss;
  for(int i=fn; i<fn+n; i++){
    oss.str("");
    oss << "fit_" << TH1F::GetName() << "_" << i;
    fTF1[i] = ConstTF1(oss.str());
  }
  nfit = fn + n;
}

Int_t GPeakFitBase::GetFN()
{
  return fn;
}

void GPeakFitBase::SetFN(Int_t fitn)
{
  if(CheckFN(fitn))
    fn = fitn;
  else
    cout << "[GPeakFitBase-E]: invalit fit number" << endl;
}

void GPeakFitBase::SetParameters(Double_t *par, Int_t fitn)
{
  if(CheckFN(fitn))
    fn = fitn;
  fTF1[fn]->SetParameters( par );
}

Double_t GPeakFitBase::GFit(Option_t* option, Option_t* goption, Double_t xmin, Double_t xmax, Int_t fitn)
{
  if(CheckFN(fitn))
    fn = fitn;
  if(!xmin && !xmax)
    fTF1[fn]->GetRange(xmin, xmax);
  Fit(fTF1[fn], option, goption, xmin, xmax);
  Double_t chisq = fTF1[fn]->GetChisquare();
  cout << "[GPeakFitBase-N]: Fitted by fTF1[" << fn << "]." << endl;
  fn++;
  if(fn >= nfit){
    cout << "[GPeakFitBase-W]: reached to the maximum number of TF1." << endl;
    fn--;
  }
  return chisq;
}
