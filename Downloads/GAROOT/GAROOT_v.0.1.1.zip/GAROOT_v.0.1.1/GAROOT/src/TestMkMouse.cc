#include "setgfroot.h"
#include "MkMouse.h"

void TestMkMouse(){
  gROOT->ProcessLine(".L GAROOT/src/MkMouse.cc");
  TCanvas *canv = new TCanvas("canv","canv");
  MkMouse *fMkMouse = new MkMouse(NM_MAX);
  TH1F *h = (TH1F*)_file0->Get("h101");
  h->Draw("");
  fMkMouse->fTMarker[0]->Draw("");
  canv->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "MkMouse", fMkMouse, "SetMarker(Int_t,Int_t,Int_t,TObject*)");
}
