#include <fstream>
#include "GPeakFit.h"
#include "MkMouse.h"
#include <TCanvas.h>
#include <TMarker.h>
#include <TStyle.h>
#include <TPad.h>
#include <RQ_OBJECT>

class Gf3ROOT
{
  RQ_OBJECT("Gf3ROOT")
 protected:
  Int_t n_hist; //number of histograms
  Int_t hid; //current histogram number
  Int_t mode; //current mode. (0:normal, 1:qf mode)
  Double_t xmin_com, xmax_com; //common range
  Int_t CheckHN(Int_t hn); //check if input histn is valid
  Option_t* op; //option for fitting
  Option_t* gop; //goption for fitting
  void Fit(Int_t event,Int_t px,Int_t py,TObject* sel); //Fit
  void QFit(Int_t event,Int_t px,Int_t py,TObject* sel); //QuickFit
  void Expand(Double_t x);
  void ConnectShortCut();

 public:
  MkMouse *fMkMouse;
  TCanvas *fTCanvas;
  GPeakFit* fGPeakFit[NH_MAX];

  Gf3ROOT(Int_t Nhist, TH1F* fTH1F[NH_MAX]);
  ~Gf3ROOT(void);
  void ExecuteShortCut(Int_t event,Int_t px,Int_t py,TObject* sel);
  void fn(Int_t fitn);
  void nf(Option_t* option = "", Option_t* goption = ""); //new fit
  void qf(); //sets quick fit mode
  void esc(); //escapes
  void ht(Int_t id = -1); //draws histogram
  void hn(); //next histogram
  void hb(); //previous histogram
  void fn(); //next TF1
  void fb(); //previous TF1
  void zoom(Double_t low, Double_t up); //zoom all histograms
  void unzoom(); //unzoom all histograms
  void WriteCSV(string ofname, Int_t fidlow = 0, Int_t fidup = NF_MAX); //writes fitting parameters into a csv file.
};
