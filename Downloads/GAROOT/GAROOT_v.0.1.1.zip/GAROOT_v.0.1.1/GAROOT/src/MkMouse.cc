#include "MkMouse.h"

MkMouse::MkMouse(Int_t nmk)
{
  mkmax = nmk;
  for(int i=0; i<nmk; i++){
    fTMarker[i] = new TMarker(0,0,23);
    fTMarker[i]->SetMarkerColor(i+2);
  }
  mknum = 0;
}

MkMouse::~MkMouse(void){}

void MkMouse::SetMarker(Int_t event, Int_t px, Int_t py, TObject *sel)
{
   TCanvas *c = (TCanvas *) gTQSender;
   TPad *pad = (TPad *) c->GetSelectedPad();
   if (event == kButton1Down) {
     if(mknum == NM_MAX){
       cout << "[MkMouse-E]: No more markers." << endl;
       return;
     }
      Float_t x = pad->AbsPixeltoX(px);
      Float_t y = pad->AbsPixeltoY(py);
      x = pad->PadtoX(x);
      y = pad->PadtoY(y);
      fTMarker[mknum]->SetX(x);
      fTMarker[mknum]->SetY(y);
      fTMarker[mknum]->Draw("");
      mknum++;
   }
   return;
}

void MkMouse::Clear(void)
{
  mknum = 0;
  for(int i=0; i<mkmax; i++){
    fTMarker[i]->SetX(0.0);
    fTMarker[i]->SetY(0.0);
  }
}

void MkMouse::GetMkPos(Double_t *mkpos)
{
  for(int i=0; i<NM_MAX; i++){
    *(mkpos+i) = fTMarker[i]->GetX();
    *(mkpos+i+NM_MAX) = fTMarker[i]->GetY();
  }
}

Int_t MkMouse::GetMkNum(void)
{
  return mknum;
}
