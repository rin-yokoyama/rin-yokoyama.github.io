#include <iostream>
#include <string>
#include <sstream>
#include <TH1.h>
#include <TF1.h>
using namespace std;

//This is a base class for peak fitting of a gamma spectrum.

class GPeakFitBase : public TH1F
{
 protected:
  Int_t nfit; //total number of TF1s
  Int_t fn; //current TF1 number
  TF1 *fTF1[NF_MAX];
  virtual TF1* ConstTF1(string f_name,Double_t xmin = 0, Double_t xmax = 10000);   // This will create a fitting function for gamma peaks.
  void ConstN(Int_t n); //This will create fTF1[0] to [n]
  Int_t CheckFN(Int_t fitn);

 public:
  GPeakFitBase(TH1F* hist, Int_t n_fit = NF_MAX);
  virtual ~GPeakFitBase(void);
  TF1* GetTF1(Int_t fitn = -1); //returns fTF1[fn]
  Int_t GetFN();
  void SetFN(Int_t fitn);
  void SetParameters(Double_t *par, Int_t fitn = -1); //sets par as parameters
  virtual Double_t GFit(Option_t* option = "", Option_t* goption = "", Double_t xmin = 0, Double_t xmax = 0, Int_t fitn = -1); //fits this TH1 with fTF1[fnum]
};
