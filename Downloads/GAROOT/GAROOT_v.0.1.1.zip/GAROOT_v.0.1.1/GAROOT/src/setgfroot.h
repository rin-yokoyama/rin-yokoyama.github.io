#define FIX_PRM "GAROOT/prm/fixparam.txt"
#define NH_MAX 128 //maximum number of histograms
#define NF_MAX 64 //maximum number of TF1s
#define NP_MAX 5 //maximum number of peaks
#define NM_MAX  NP_MAX+2 //maximum number of markers

#define E_RES 1.E-3 //energy resolution
#define QF_R 20 //+-range of the quick fitting (QF_R*E_RES*[center] will be the range)
