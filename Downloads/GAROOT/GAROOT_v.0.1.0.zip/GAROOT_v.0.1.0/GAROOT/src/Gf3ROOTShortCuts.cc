#include "Gf3ROOT.h"

//defines shortcuts of Gf3ROOT functions
void Gf3ROOT::ExecuteShortCut(Int_t event,Int_t px,Int_t py,TObject* sel)
{
  if(event==kWheelDown)
    hn();
  else if(event == kWheelUp)
    hb();
  else if(event == kButton1Shift){ //shift+click
    TCanvas *c = (TCanvas *) gTQSender;
    TPad *pad = (TPad *) c->GetSelectedPad();
    Float_t x = pad->AbsPixeltoX(px);
    Float_t y = pad->AbsPixeltoY(py);
    x = pad->PadtoX(x);
    y = pad->PadtoY(y);
    Expand(x);
  }
  else if(event == kKeyPress){
    if((!px) && (py == 4114)) //<-
      fb();
    if((!px) && (py == 4116)) //->
      fn();
    if((px == 6) && (py == 70) && !mode) //ctr+f
      nf();
    if((px == 17) && (py == 81)) //ctr+q
      qf();
    if((px == 21) && (py == 85)) //ctr+u
      unzoom();
    if((px == 5) && (py == 69)) //ctr+e
      esc();
  }
}
