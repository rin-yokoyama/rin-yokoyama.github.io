#include "GPeakFit.h"

GPeakFit::GPeakFit(TH1F* hist, Int_t n_fit) : GPeakFitBase(hist, n_fit)
{
  ERes = E_RES;
  for(int i=0; i<6*NP_MAX+3; i++){
    FixPar[i] = 0;
    FixParVal[i] = 0.0;
  }
}

GPeakFit::~GPeakFit(void){}

TF1* GPeakFit::ConstTF1(string f_name, Int_t npk, Double_t xmin, Double_t xmax)
{
  TF1* func;
  ostringstream f_expr, f_parname;
  // creating function expression
  if(npk > NP_MAX){
    cout << "[GPeakFit-E]: invalid number of peaks." << endl;
    npk = 1;
  }
  f_expr.str("");
  f_expr << "pol2(0)";
  for(int i=0; i<npk; i++){
    int j = 6*i;
    f_expr << "+[" << j+6 << "]*[" << 6*npk+3 << "]*gaus(" << j+3 << ")/([" << j+5 << "]*sqrt(2*TMath::Pi()))+(1-[" << j+6 << "])*[" << j+3 << "]*[" << 6*npk+3 << "]*exp((x-[" << j+4 << "])/[" << j+7 << "])*TMath::Erfc((x-[" << j+4 << "])/(sqrt(2)*[" << j+5 << "])+[" << j+5 << "]/(sqrt(2)*[" << j+7 << "]))+[" << j+3 << "]*[" << 6*npk+3 << "]*[" << j+8 << "]*TMath::Erfc((x-[" << j+4 << "])/(sqrt(2)*[" << j+5 << "]))";
  }

  //construction of TF1
  func = new TF1(f_name.c_str(), f_expr.str().c_str(), xmin, xmax);

  //setting parameter names
  for(int i=0; i<3; i++){
    f_parname.str("");
    f_parname << "BG" << i;
    func->SetParName(i, f_parname.str().c_str());
  }
  string parstr[6] = {"area","center","sigma","R","beta","step"};
  for(int i=0; i<npk; i++){
    for(int j=0; j<6; j++){
      f_parname.str("");
      f_parname << parstr[j] << i;
      func->SetParName(6*i+j+3, f_parname.str().c_str());
    }
  }
  func->SetParName(6*npk+3, "gain");

  //initialization of the parameters
  for(int i=0; i<npk*6+4; i++)
    func->SetParameter(i,1.0);

  //setting line style
  *func = GFitLine;

  return (TF1*)func->Clone();
}

void GPeakFit::ClearTF1(Int_t fitn)
{
  if(CheckFN(fitn))
    fitn = fn;
  string fname.str(fTF1[fitn]->GetName());
  fTF1[fitn] = GPeakFit::ConstTF1(fname);
}

 void GPeakFit::FixParams()
 {
   Int_t npk = (fTF1[fn]->GetNpar() - 3)/6;
   ostringstream oss;
   oss.str("");
   string mpath = gROOT->GetMacroPath();
   mpath = mpath.substr(2);
   mpath = mpath.substr(0,mpath.size()-1);
   oss << mpath << "/" << FIX_PRM;
   ifstream fin(oss.str().c_str(), ios::in);
   if(!fin){ cout << "[GPeakFit-E]: cannot open fixpar file." << endl; return; }
   for(int i=0; i<6*npk+3; i++){
     fin >> FixPar[i];
     fin >> FixParVal[i];
     if(fin.eof()){
       cout << "[GPeakFit-E]: invalid fixpar file." << endl;
       fin.close();
       return;
     }
   }
   fin.close();
   for(int i=0; i<6*npk+3; i++){
     if(FixPar[i])
       fTF1[fn]->FixParameter(i, FixParVal[i]);
   }
   fTF1[fn]->FixParameter(6*npk+3, GetBinWidth(0));
 }

 void GPeakFit::SetFitting(Int_t npk, Double_t mkpos[2][NM_MAX], Int_t fitn )
 {
   if(CheckFN(fitn))
     fn = fitn;
   string fname = fTF1[fn]->GetName();
   fTF1[fn] = ConstTF1(fname, npk, mkpos[0][0], mkpos[0][1]);
   fTF1[fn]->SetParameter(0,(mkpos[1][0]*mkpos[0][1] - mkpos[1][1]*mkpos[0][0])/(mkpos[0][1]-mkpos[0][0]));
   fTF1[fn]->SetParameter(1, (mkpos[1][1]-mkpos[1][0])/(mkpos[0][1]-mkpos[0][0]));
   fTF1[fn]->SetParameter(2, 0.0);
   for(int i=0; i<npk; i++){
     fTF1[fn]->SetParameter(6*i+3, mkpos[1][i+2]);
     fTF1[fn]->SetParameter(6*i+4, mkpos[0][i+2]);
     fTF1[fn]->SetParameter(6*i+5, mkpos[0][i+2]*ERes);
     fTF1[fn]->SetParameter(6*i+6, 0.9);
     fTF1[fn]->SetParameter(6*i+7, 0.5);
     fTF1[fn]->SetParameter(6*i+8, 0.01);
   }
   FixParams();
 }

void GPeakFit::DrawBG(Int_t fitn)
{
   if(!CheckFN(fitn))
     fitn = fn;
   Int_t npk = (fTF1[fitn]->GetNpar() - 3)/6;
  ostringstream bg_expr;
  bg_expr.str("");
  bg_expr << "pol2(0)";
  for(int i=0; i<npk; i++){
    int j = 4*i;
    bg_expr << "+[" << j+3 << "]*[" << 4*npk+3 << "]*[" << j+6 << "]*TMath::Erfc((x-[" << j+4 << "])/(sqrt(2)*[" << j+5 << "]))";
  }
  string bgname = GetName();
  bgname.append("_bg");
  fTF1BG = new TF1(bgname.c_str(), bg_expr.str().c_str(), fTF1[fitn]->GetXmin(), fTF1[fitn]->GetXmax());
  *fTF1BG = GBGLine;

  fTF1BG->SetParameter(0, fTF1[fitn]->GetParameter(0));
  fTF1BG->SetParameter(1, fTF1[fitn]->GetParameter(1));
  fTF1BG->SetParameter(2, fTF1[fitn]->GetParameter(2));
  for(int i=0; i<npk; i++){
    int j=6*i;
    int k=4*i;
    fTF1BG->SetParameter(k+3, fTF1[fitn]->GetParameter(j+3));
    fTF1BG->SetParameter(k+4, fTF1[fitn]->GetParameter(j+4));
    fTF1BG->SetParameter(k+5, fTF1[fitn]->GetParameter(j+5));
    fTF1BG->SetParameter(k+6, fTF1[fitn]->GetParameter(j+8));
  }
  fTF1BG->SetParameter(4*npk+3, fTF1[fitn]->GetParameter(6*npk+3));
  fTF1BG->Draw("same");
}
