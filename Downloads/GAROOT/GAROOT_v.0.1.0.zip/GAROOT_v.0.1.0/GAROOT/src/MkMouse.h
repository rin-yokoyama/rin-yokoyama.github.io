#include <TMarker.h>
#include <TCanvas.h>
#include <TPad.h>
#include <RQ_OBJECT.h>
//This class draws marker when it gets a mouse click signal from canvas.
class MkMouse
{
  RQ_OBJECT("MkMouse")
 protected:
  Int_t mkmax;
  Int_t mknum;

 public:
  TMarker *fTMarker[NM_MAX];
  MkMouse(Int_t nmk = NM_MAX);
  ~MkMouse(void);
  void SetMarker(Int_t event, Int_t px, Int_t py, TObject *sel);
  void Clear(void); //clears marker positions and mknum.
  void GetMkPos(Double_t *mkpos); //returns marker positions into mkpos.
  Int_t GetMkNum(void);
};
