#include "Gf3ROOT.h"
#include <TList.h>
#include <TKey.h>

TFile *file;
TList *fList;
Gf3ROOT *g;
TH1F* hist[NH_MAX];

//This will read all histograms from file and create Gf3ROOT class.
void GfMain(string fname)
{
  if(fname == "_file0")
    file = _file0;
  else
    file = new TFile(fname.c_str());
  fList = file->GetListOfKeys();
  Int_t nkey = fList->GetEntries();
  if(nkey > NH_MAX){
    cout << "[GfROOT-E]: Too much histograms in this file. (MAX:" << NH_MAX << ")" << endl;
    return;
  }
  int j = 0;
  for(int i=0; i<nkey; i++){
    TKey* fKey = (TKey*)fList->At(i);
    if(fKey->ReadObj()->InheritsFrom("TH1")){
      hist[j] = (TH1F*)fKey->ReadObj();
      j++;
    }
  }
  if(!j){
    cout << "[GfROOT-E]: There is no object which inherits from TH1." << endl;
    return;
  }
  g = new Gf3ROOT(nkey, hist);
}
