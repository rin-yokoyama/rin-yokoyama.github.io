#include "Gf3ROOT.h"

Gf3ROOT::Gf3ROOT(Int_t Nhist, TH1F* fTH1F[NH_MAX])
{
  n_hist = Nhist;
  for(int i=0; i<n_hist; i++){
    fGPeakFit[i] = new GPeakFit(fTH1F[i]);
    *fGPeakFit[i] = GHistLine;
    *fGPeakFit[i] = GHistFill;
  }
  fMkMouse = new MkMouse(NM_MAX);
  fTCanvas = new TCanvas("Gcanv","GfROOT");
  gStyle->SetOptFit();
  hid = 0;
  ht();
  ConnectShortCut();
  mode = 0;
}

Gf3ROOT::~Gf3ROOT(void){}

Int_t  Gf3ROOT::CheckHN(Int_t hn)
{
  if( (hn<0) || (hn>=n_hist) )
    return 0;
  else
    return 1;
}

void Gf3ROOT::ConnectShortCut(void)
{
  fTCanvas->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "Gf3ROOT", this, "ExecuteShortCut(Int_t, Int_t, Int_t, TObject*)");
}

void Gf3ROOT::Fit(Int_t event,Int_t px,Int_t py,TObject* sel)
{
  if(event == kButton3Down){
    Int_t mknum = fMkMouse->GetMkNum();
    if(mknum<=2){
      cout << "[Gf3ROOT-E]: You need at reast 3 markers to fit." << endl;
      return;
    }
    Double_t mkpos[2][NM_MAX];
    for(int i=0; i<2; i++){
      for(int j=0; j<NM_MAX; j++)
	mkpos[i][j]=0;
    }
    fTCanvas->Disconnect();
    ConnectShortCut();
    fMkMouse->GetMkPos(&mkpos[0][0]);
    fGPeakFit[hid]->SetFitting(mknum-2, &mkpos);
    fGPeakFit[hid]->GFit(op,gop);
    fGPeakFit[hid]->DrawBG(fGPeakFit[hid]->GetFN()-1);
    fTCanvas->Update();
  }
}

void Gf3ROOT::QFit(Int_t event,Int_t px,Int_t py,TObject* sel)
{
   TCanvas *c = (TCanvas *) gTQSender;
   TPad *pad = (TPad *) c->GetSelectedPad();
  if(event == kButton1Down){
    Double_t mkpos[2][NM_MAX];
    for(int i=0; i<2; i++){
      for(int j=0; j<NM_MAX; j++)
	mkpos[i][j]=0;
    }
    Float_t x = pad->AbsPixeltoX(px);
    Float_t y = pad->AbsPixeltoY(py);
    x = pad->PadtoX(x);
    y = pad->PadtoY(y);
    mkpos[0][2] = x;
    mkpos[1][2] = y;
    mkpos[0][0] = x - x*E_RES*QF_R;
    mkpos[0][1] = x + x*E_RES*QF_R;
    mkpos[1][0] = fGPeakFit[hid]->GetBinContent( fGPeakFit[hid]->FindBin(mkpos[0][0]) );
    mkpos[1][1] = fGPeakFit[hid]->GetBinContent( fGPeakFit[hid]->FindBin(mkpos[0][1]) );
    fGPeakFit[hid]->SetFitting(1, &mkpos);
    fGPeakFit[hid]->GFit("", "");
    fGPeakFit[hid]->DrawBG(fGPeakFit[hid]->GetFN()-1);
    fTCanvas->Update();
  }else if(event == kButton3Down){
    fGPeakFit[hid]->SetFN( fGPeakFit[hid]->GetFN() - 1 );
    cout << "Redo fTF1[" << fGPeakFit[hid]->GetFN() << "]" << endl;
  }
}

void Gf3ROOT::Expand(Double_t x)
{
  if(!mode){
    xmin_com = x;
    mode = 2;
    return;
  }
  else if(mode == 2){
    xmax_com = x;
    mode = 0;
    zoom(xmin_com,xmax_com);
    return;
  }
}

void Gf3ROOT::fn(Int_t fitn){ fGPeakFit[hid]->SetFN(fitn); }

void Gf3ROOT::nf(Option_t* option, Option_t* goption)
{
  fMkMouse->Clear();
  fTCanvas->Disconnect();
  fTCanvas->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "MkMouse", fMkMouse, "SetMarker(Int_t,Int_t,Int_t,TObject*)");
  fTCanvas->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "Gf3ROOT", this, "Fit(Int_t, Int_t, Int_t, TObject*)");
  op = option;
  gop = goption;
  cout << "Set Markers for Fitting." << endl;
}

void Gf3ROOT::qf()
{
  fTCanvas->Connect("ProcessedEvent(Int_t,Int_t,Int_t,TObject*)", "Gf3ROOT", this, "QFit(Int_t, Int_t, Int_t, TObject*)");
  mode = 1;
  cout << "\n***Quick Fit Mode***\nPress ESC to end this mode." << endl;
}

void Gf3ROOT::esc()
{
  cout << "\nESCAPE" << endl;
  fTCanvas->Disconnect();
  ConnectShortCut();
  mode = 0;
}

void Gf3ROOT::ht(Int_t id)
{
  if(CheckHN(id)){ hid = id; }
  fGPeakFit[hid]->Draw("");
}

void Gf3ROOT::hn()
{
  if(hid < n_hist-1)
    hid++;
  fGPeakFit[hid]->Draw("");
  fTCanvas->Update();
}

void Gf3ROOT::hb()
{
  if(0 < hid)
    hid--;
  fGPeakFit[hid]->Draw("");
  fTCanvas->Update();
}

void Gf3ROOT::fn()
{
    fGPeakFit[hid]->SetFN( fGPeakFit[hid]->GetFN() + 1 );
    cout << "Next Fit: fTF1[" << fGPeakFit[hid]->GetFN() << "]" << endl;
}

void Gf3ROOT::fb()
{
    fGPeakFit[hid]->SetFN( fGPeakFit[hid]->GetFN() - 1 );
    cout << "Next Fit: fTF1[" << fGPeakFit[hid]->GetFN() << "]" << endl;
}

void Gf3ROOT::zoom(Double_t low, Double_t up)
{
  for(int i=0; i<n_hist; i++)
    fGPeakFit[i]->SetAxisRange(low,up);
  fGPeakFit[hid]->Draw("");
  fTCanvas->Update();
}

void Gf3ROOT::unzoom()
{
  for(int i=0; i<n_hist; i++){
    fGPeakFit[i]->GetXaxis()->UnZoom();
    fGPeakFit[i]->GetYaxis()->UnZoom();
  }
  fGPeakFit[hid]->Draw("");
  fTCanvas->Update();
}

void Gf3ROOT::WriteCSV(string ofname, Int_t fidlow, Int_t fidup)
{
  ofstream ofile(ofname.c_str(), ios::out);
  //finding a fTF1 with the largest number of peaks.
  Int_t fmax[3] = {0,0,0};
  for(int i=0; i<n_hist; i++){
    for(int j=fidlow; j<fidup+1; j++){
      if(fmax[2] < fGPeakFit[i]->GetTF1(j)->GetNpar()){
	fmax[0] = i;
	fmax[1] = j;
	fmax[2] = fGPeakFit[i]->GetTF1(j)->GetNpar();
      }
    }
  }
  //writes output csv file.
  ofile << "Hist_N, " << "Fit_N, " << "Chisquare, ";
  for(int i=0; i<fmax[2]; i++)
    ofile << fGPeakFit[fmax[0]]->GetTF1(fmax[1])->GetParName(i) << ", error, ";
  ofile << endl;
  for(int i=0; i<n_hist; i++){
    for(int j=fidlow; j<fidup+1; j++){
      ofile << i << ", " << j << ", ";
      ofile << fGPeakFit[i]->GetTF1(j)->GetChisquare() << ", ";
      for(int k=0; k<fmax[2]; k++){
	ofile << fGPeakFit[i]->GetTF1(j)->GetParameter(k) << ", ";
	ofile << fGPeakFit[i]->GetTF1(j)->GetParError(k) << ", ";
      }
      ofile << endl;
    }
  }
  ofile.close();
}
