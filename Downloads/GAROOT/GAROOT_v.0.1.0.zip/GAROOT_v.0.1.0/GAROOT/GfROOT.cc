void GfROOT(string fname = "_file0")
{
  gROOT->ProcessLine(".L GAROOT/src/setgfroot.h");
  gROOT->ProcessLine(".L GAROOT/src/Styles.h");
  gROOT->ProcessLine(".L GAROOT/src/GPeakFitBase.cc");
  gROOT->ProcessLine(".L GAROOT/src/GPeakFit.cc");
  gROOT->ProcessLine(".L GAROOT/src/MkMouse.cc");
  gROOT->ProcessLine(".L GAROOT/src/Gf3ROOT.cc");
  gROOT->ProcessLine(".L GAROOT/src/Gf3ROOTShortCuts.cc");
  gROOT->ProcessLine(".L GAROOT/src/GfMain.cc");
  GfMain(fname);    
}
